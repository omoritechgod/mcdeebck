-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 22, 2025 at 02:14 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcdee_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'info@mac.com', '$2y$12$WcD9sBQuytUwnUeRB4Tii.WYghbw0eILA4KtClXXYGYQ/8W3Ht3A2', NULL, '2025-07-29 00:12:34', '2025-07-29 00:12:34');

-- --------------------------------------------------------

--
-- Table structure for table `admin_transactions`
--

CREATE TABLE `admin_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `admin_wallet_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('credit','debit') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `status` enum('pending','success','failed') NOT NULL DEFAULT 'pending',
  `description` varchar(255) DEFAULT NULL,
  `related_id` bigint(20) UNSIGNED DEFAULT NULL,
  `related_type` varchar(255) DEFAULT NULL,
  `meta` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`meta`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_transactions`
--

INSERT INTO `admin_transactions` (`id`, `admin_wallet_id`, `type`, `amount`, `ref`, `status`, `description`, `related_id`, `related_type`, `meta`, `created_at`, `updated_at`) VALUES
(1, 1, 'credit', 80.00, 'booking_1', 'success', NULL, NULL, NULL, '\"{\\\"source\\\":\\\"checkout_payout\\\"}\"', '2025-08-11 05:55:25', '2025-08-11 05:55:25'),
(2, 1, 'credit', 20.00, 'ye5h3qm1rx', 'success', NULL, NULL, NULL, '\"{\\\"payment_gateway\\\":\\\"paystack\\\"}\"', '2025-08-13 05:37:32', '2025-08-13 05:37:32'),
(3, 2, 'credit', 20.00, 'flw_test_ref_SO3', 'success', NULL, NULL, NULL, '{\"payment_gateway\":\"flutterwave\",\"entity\":\"service_order\",\"entity_id\":3}', '2025-08-17 02:14:17', '2025-08-17 02:14:17'),
(4, 2, 'credit', 20.00, 'flw_test_ref_SO3', 'success', NULL, NULL, NULL, '{\"payment_gateway\":\"flutterwave\",\"entity\":\"service_order\",\"entity_id\":3}', '2025-08-17 02:28:09', '2025-08-17 02:28:09');

-- --------------------------------------------------------

--
-- Table structure for table `admin_wallets`
--

CREATE TABLE `admin_wallets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT 'Main Company Wallet',
  `balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(255) NOT NULL DEFAULT 'NGN',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_wallets`
--

INSERT INTO `admin_wallets` (`id`, `name`, `balance`, `currency`, `created_at`, `updated_at`) VALUES
(1, 'Main Company Wallet', 100.00, 'NGN', '2025-08-11 01:47:12', '2025-08-13 05:37:32'),
(2, 'Main', 40.00, 'NGN', '2025-08-17 02:14:17', '2025-08-17 02:28:09');

-- --------------------------------------------------------

--
-- Table structure for table `apartments`
--

CREATE TABLE `apartments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `price_per_night` decimal(12,2) NOT NULL,
  `type` enum('hotel','hostel','shortlet') NOT NULL,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `apartments`
--

INSERT INTO `apartments` (`id`, `vendor_id`, `title`, `description`, `location`, `price_per_night`, `type`, `is_verified`, `images`, `features`, `created_at`, `updated_at`) VALUES
(28, 31, 'Asuu_Apartment – VII', 'Sea view, smart home tech', 'Gra, Port harcourt', 25000.00, 'shortlet', 1, '[]', NULL, '2025-08-05 01:10:10', '2025-08-05 01:10:10');

-- --------------------------------------------------------

--
-- Table structure for table `apartment_bookings`
--

CREATE TABLE `apartment_bookings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `apartment_id` bigint(20) UNSIGNED NOT NULL,
  `check_in` date NOT NULL,
  `check_out` date NOT NULL,
  `total_price` decimal(12,2) NOT NULL,
  `status` enum('pending','confirmed','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `listing_id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `check_in_date` date NOT NULL,
  `check_out_date` date NOT NULL,
  `nights` int(11) NOT NULL,
  `total_price` decimal(12,2) NOT NULL,
  `status` enum('pending','processing','paid','checked_in','checked_out','completed','cancelled','refunded') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `user_id`, `listing_id`, `vendor_id`, `check_in_date`, `check_out_date`, `nights`, `total_price`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(1, 23, 2, 31, '2025-08-10', '2025-08-10', 2, 800.00, 'checked_out', 'Please prepare towels.', '2025-08-09 12:27:38', '2025-08-11 05:55:25'),
(2, 23, 3, 31, '2025-08-14', '2025-08-15', 1, 200.00, 'paid', NULL, '2025-08-13 03:55:57', '2025-08-15 11:38:16'),
(3, 23, 3, 31, '2025-08-20', '2025-08-22', 2, 400.00, 'paid', 'Prepare Towel', '2025-08-18 18:33:48', '2025-08-18 18:48:30');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `item_type` varchar(255) NOT NULL,
  `item_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `food_menus`
--

CREATE TABLE `food_menus` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `food_orders`
--

CREATE TABLE `food_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('pending','preparing','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `food_order_items`
--

CREATE TABLE `food_order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `food_order_id` bigint(20) UNSIGNED NOT NULL,
  `food_menu_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `food_vendors`
--

CREATE TABLE `food_vendors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `business_name` varchar(255) NOT NULL,
  `specialty` varchar(255) NOT NULL,
  `location` varchar(255) NOT NULL,
  `contact_phone` varchar(255) NOT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `food_vendors`
--

INSERT INTO `food_vendors` (`id`, `vendor_id`, `business_name`, `specialty`, `location`, `contact_phone`, `contact_email`, `description`, `logo`, `created_at`, `updated_at`) VALUES
(1, 20, 'Mama Blessing Kitchen', 'Nigerian delicacies', 'Wuse 2, Abuja', '08012345678', 'mamablessing@gmail.com', 'We offer healthy home-cooked meals.', 'uploads/logos/mama.png', '2025-08-01 23:58:02', '2025-08-01 23:58:02');

-- --------------------------------------------------------

--
-- Table structure for table `gps_logs`
--

CREATE TABLE `gps_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ride_id` bigint(20) UNSIGNED NOT NULL,
  `lat` decimal(10,6) NOT NULL,
  `lng` decimal(10,6) NOT NULL,
  `logged_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `listings`
--

CREATE TABLE `listings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `price_per_night` decimal(10,2) NOT NULL,
  `type` enum('hostel','hotel','shortlet') NOT NULL,
  `images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`images`)),
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `listings`
--

INSERT INTO `listings` (`id`, `vendor_id`, `title`, `description`, `location`, `price_per_night`, `type`, `images`, `is_verified`, `created_at`, `updated_at`) VALUES
(2, 31, 'House in VA', 'test', 'Port Harcourt', 400.00, 'shortlet', '[\"https:\\/\\/res.cloudinary.com\\/djgqgpgjb\\/image\\/upload\\/v1754380418\\/j2eub6gayccxdgvedf1j.png\"]', 1, '2025-08-05 06:53:41', '2025-08-05 06:53:41'),
(3, 31, 'Cozy', 'gdflf', 'GRA', 200.00, 'hotel', '[\"https:\\/\\/res.cloudinary.com\\/djgqgpgjb\\/image\\/upload\\/v1755046351\\/cmg8udbenggedhqyyy3r.webp\"]', 1, '2025-08-12 23:52:34', '2025-08-12 23:52:34');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_requests`
--

CREATE TABLE `maintenance_requests` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `location` varchar(255) NOT NULL,
  `service_type` varchar(255) NOT NULL,
  `issue` text NOT NULL,
  `needs_towing` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('pending','accepted','completed','cancelled') NOT NULL DEFAULT 'pending',
  `mechanic_id` bigint(20) UNSIGNED DEFAULT NULL,
  `accepted_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `maintenance_requests`
--

INSERT INTO `maintenance_requests` (`id`, `user_id`, `location`, `service_type`, `issue`, `needs_towing`, `status`, `mechanic_id`, `accepted_at`, `completed_at`, `created_at`, `updated_at`) VALUES
(1, 23, '23 GRA Road, Port Harcourt', 'Brake Failure', 'The brakes don’t respond when pressed', 1, 'accepted', NULL, '2025-07-23 14:27:16', NULL, '2025-07-23 14:24:14', '2025-07-23 14:27:16'),
(2, 23, '24 GRA Road, Port Harcourt', 'Flat tire', 'The brakes don’t respond when pressed', 1, 'pending', NULL, NULL, NULL, '2025-07-23 14:59:48', '2025-07-23 14:59:48'),
(3, 23, 'Current Location', 'Electrical', 'light not coming up', 0, 'pending', NULL, NULL, NULL, '2025-07-23 15:55:58', '2025-07-23 15:55:58');

-- --------------------------------------------------------

--
-- Table structure for table `mechanics`
--

CREATE TABLE `mechanics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `workshop_name` varchar(255) DEFAULT NULL,
  `services_offered` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `contact_number` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mechanics`
--

INSERT INTO `mechanics` (`id`, `user_id`, `vendor_id`, `workshop_name`, `services_offered`, `location`, `contact_number`, `status`, `created_at`, `updated_at`) VALUES
(1, 20, 5, 'FixIt Autos', 'Oil change, Brake repair, Diagnostics', 'Ikeja, Lagos', '+2348012345678', 'pending', '2025-07-06 16:36:31', '2025-07-06 16:36:31'),
(2, 21, 6, 'FixIt Autos', 'Oil change, Brake repair, Diagnostics', 'Ikeja, Lagos', '+2348012345678', 'pending', '2025-07-06 16:44:10', '2025-07-06 16:44:10'),
(7, 48, 29, 'Mechtg', 'Oil Change', 'okocha', '08105182900', 'pending', '2025-08-02 22:23:26', '2025-08-02 22:23:26');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(56, '0001_01_01_000000_create_users_table', 1),
(57, '0001_01_01_000001_create_cache_table', 1),
(58, '0001_01_01_000002_create_jobs_table', 1),
(59, '2025_07_03_221111_create_vendors_table', 1),
(60, '2025_07_03_221111_create_verifications_table', 1),
(61, '2025_07_03_221112_create_wallets_table', 1),
(62, '2025_07_03_221113_create_wallet_transactions_table', 1),
(63, '2025_07_03_221114_create_p2p_transfers_table', 1),
(64, '2025_07_03_221727_create_personal_access_tokens_table', 1),
(65, '2025_07_03_221729_create_product_categories_table', 1),
(66, '2025_07_03_221735_create_products_table', 1),
(67, '2025_07_04_070758_create_orders_table', 1),
(68, '2025_07_04_070759_create_order_items_table', 1),
(69, '2025_07_04_070905_create_product_reviews_table', 1),
(70, '2025_07_04_073910_create_carts_table', 1),
(71, '2025_07_04_084143_create_food_menus_table', 1),
(72, '2025_07_04_084224_create_food_orders_table', 1),
(73, '2025_07_04_084258_create_food_order_items_table', 1),
(74, '2025_07_04_085924_create_riders_table', 1),
(75, '2025_07_04_090018_create_rides_table', 1),
(76, '2025_07_04_090107_create_gps_logs_table', 1),
(77, '2025_07_04_091115_create_ride_settings_table', 1),
(78, '2025_07_04_095629_create_apartments_table', 1),
(79, '2025_07_04_095630_create_apartment_bookings_table', 1),
(80, '2025_07_04_100652_create_ride_ratings_table', 1),
(81, '2025_07_04_114209_create_maintenance_requests_table', 1),
(82, '2025_07_04_121817_create_mechanics_table', 1),
(83, '2025_07_04_121819_create_service_apartments_table', 1),
(84, '2025_07_04_151127_create_product_vendors_table', 1),
(85, '2025_07_05_180749_create_food_vendors_table', 2),
(86, '2025_01_31_001827_create_subscriptions_table', 3),
(87, '2025_07_23_184755_create_email_otps_table', 4),
(88, '2025_07_29_010949_admin_table', 5),
(90, '2025_08_01_230221_add_is_setup_complete_to_vendors_table', 6),
(92, '2025_08_05_045934_create_listings_table', 7),
(93, '2025_08_09_131754_create_bookings_table', 8),
(94, '2025_08_11_023623_create_admin_wallets_table', 9),
(95, '2025_08_11_023836_create_admin_transactions_table', 9),
(96, '2025_08_17_000001_create_service_pricings_table', 10),
(97, '2025_08_17_000002_add_service_pricing_id_to_service_orders', 10);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `status` enum('pending','processing','completed','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

CREATE TABLE `otps` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `otp` varchar(6) NOT NULL,
  `type` enum('email','phone') NOT NULL DEFAULT 'email',
  `used` tinyint(1) NOT NULL DEFAULT 0,
  `expires_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `otps`
--

INSERT INTO `otps` (`id`, `user_id`, `otp`, `type`, `used`, `expires_at`, `created_at`, `updated_at`) VALUES
(28, 48, '252', 'phone', 1, '2025-08-02 23:24:14', '2025-08-02 22:23:47', '2025-08-02 22:24:14'),
(29, 50, '801', 'phone', 1, '2025-08-07 17:12:17', '2025-08-07 16:11:50', '2025-08-07 16:12:17'),
(30, 53, '515', 'phone', 1, '2025-08-16 22:59:35', '2025-08-16 21:59:14', '2025-08-16 21:59:35');

-- --------------------------------------------------------

--
-- Table structure for table `p2p_transfers`
--

CREATE TABLE `p2p_transfers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sender_id` bigint(20) UNSIGNED NOT NULL,
  `receiver_id` bigint(20) UNSIGNED NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `status` enum('pending','completed','failed') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'auth_token', '84e7ada3c4e7228647c5230c561ca3110bc98e835fe9868f58289a6a1114ce2a', '[\"*\"]', NULL, NULL, '2025-07-05 20:26:33', '2025-07-05 20:26:33'),
(2, 'App\\Models\\User', 6, 'auth_token', '7d50f849748eb7770300411716336536dcf557549eb94ebbdd0064f1a51df250', '[\"*\"]', NULL, NULL, '2025-07-05 21:22:57', '2025-07-05 21:22:57'),
(3, 'App\\Models\\User', 7, 'auth_token', '72e46848067ab8252254205e4e901798b72e898fd4c1c98a900d347d1ac77157', '[\"*\"]', NULL, NULL, '2025-07-05 21:55:06', '2025-07-05 21:55:06'),
(4, 'App\\Models\\User', 8, 'auth_token', '16e474243a02813ced3370a721564cc438e453ac21e4c4262d953dedbf2e505d', '[\"*\"]', NULL, NULL, '2025-07-05 21:56:20', '2025-07-05 21:56:20'),
(5, 'App\\Models\\User', 9, 'auth_token', '0ec00bca62525737ead760131bc6f388321e5f482743652b9c7d97897bb1aed6', '[\"*\"]', NULL, NULL, '2025-07-05 21:57:24', '2025-07-05 21:57:24'),
(6, 'App\\Models\\User', 10, 'auth_token', '765fe34ab0fabb09599508ba0fac07a177d3169fc38fa00ed2e071c930eed214', '[\"*\"]', NULL, NULL, '2025-07-05 22:02:46', '2025-07-05 22:02:46'),
(7, 'App\\Models\\User', 11, 'auth_token', '4ea540d7f9256ee30493dcc9f2d22fd65dcb80baccfe6106b710c0f6ebff9eb5', '[\"*\"]', NULL, NULL, '2025-07-06 09:42:39', '2025-07-06 09:42:39'),
(8, 'App\\Models\\User', 12, 'auth_token', '1902c7920f0c1c50843275575bd58299bf8953d10ae94a55bbbd035ed9563aeb', '[\"*\"]', NULL, NULL, '2025-07-06 10:52:50', '2025-07-06 10:52:50'),
(9, 'App\\Models\\User', 13, 'auth_token', '5eeeecf12fa6f4ee24a00df7c9b8860012a8441a6a5977a3c776962df3e3432a', '[\"*\"]', NULL, NULL, '2025-07-06 11:49:13', '2025-07-06 11:49:13'),
(10, 'App\\Models\\User', 14, 'auth_token', 'd2077cb52bb8fe6444a63c7c9b8fab1150f30f40ce2938e92605b6b5bb33a763', '[\"*\"]', NULL, NULL, '2025-07-06 12:08:59', '2025-07-06 12:08:59'),
(11, 'App\\Models\\User', 14, 'auth_token', '6ae68548cf1de636106ac26411476e8513b4b679dec645df080f8dab766e8f59', '[\"*\"]', NULL, NULL, '2025-07-06 12:20:05', '2025-07-06 12:20:05'),
(12, 'App\\Models\\User', 15, 'auth_token', '43c40cf68e0959064613905b927dd860eb7d3bcc6579fa530b938d752a393acc', '[\"*\"]', NULL, NULL, '2025-07-06 12:36:23', '2025-07-06 12:36:23'),
(13, 'App\\Models\\User', 15, 'auth_token', '1f8cd808defae51339c5a12b7af72747d8052499b405a0ec373226a80a2f507e', '[\"*\"]', '2025-07-06 12:36:42', NULL, '2025-07-06 12:36:24', '2025-07-06 12:36:42'),
(14, 'App\\Models\\User', 15, 'auth_token', 'c27cd6ffeec966bde6dc4d5d915b8e0f882536fd62449771b6194bce94e06919', '[\"*\"]', NULL, NULL, '2025-07-06 12:37:31', '2025-07-06 12:37:31'),
(15, 'App\\Models\\User', 15, 'auth_token', '96b1b6a8a9d90fb8ff13345d9eab086f5603c9148d2395ffab6fe59eaf6af150', '[\"*\"]', '2025-07-06 12:45:57', NULL, '2025-07-06 12:44:45', '2025-07-06 12:45:57'),
(16, 'App\\Models\\User', 16, 'auth_token', '9741df2a4e7783655840b213d530ec940d0500d233b70e1ecf82c033abd925e6', '[\"*\"]', NULL, NULL, '2025-07-06 12:50:12', '2025-07-06 12:50:12'),
(17, 'App\\Models\\User', 16, 'auth_token', '824c0eb26f99fa88a16d1521e9aae335cc29e74100eadfa392b94b24359387eb', '[\"*\"]', '2025-07-06 12:50:32', NULL, '2025-07-06 12:50:13', '2025-07-06 12:50:32'),
(18, 'App\\Models\\User', 17, 'auth_token', 'e6587bf02bef7065718389108ee46faa1785355449b81c3838a318134b3ec284', '[\"*\"]', NULL, NULL, '2025-07-06 13:01:44', '2025-07-06 13:01:44'),
(19, 'App\\Models\\User', 17, 'auth_token', '880c126324f7d6e029d449a78c26a520f02d578b8e44571de40bbb129d0016d7', '[\"*\"]', '2025-07-06 13:02:57', NULL, '2025-07-06 13:01:45', '2025-07-06 13:02:57'),
(20, 'App\\Models\\User', 17, 'auth_token', '6f12410fa4b4a489a2a40e780556831f258602a4a236bb4f5154f44767e38102', '[\"*\"]', '2025-07-06 14:31:32', NULL, '2025-07-06 14:24:53', '2025-07-06 14:31:32'),
(21, 'App\\Models\\User', 18, 'auth_token', '296c5597d83f3e9b0b13b966efc4847d6e1b0f2360983dcf6a4bc7854278a8b4', '[\"*\"]', NULL, NULL, '2025-07-06 14:50:28', '2025-07-06 14:50:28'),
(22, 'App\\Models\\User', 18, 'auth_token', '92662debb21408767457fc48e19adcd0e20ad5a10dd28ae3c307de9be8d7cfc6', '[\"*\"]', '2025-07-06 15:00:13', NULL, '2025-07-06 14:50:30', '2025-07-06 15:00:13'),
(23, 'App\\Models\\User', 19, 'auth_token', '06736042530aa98177e92eab50c2f22228ca59ea24a97286052bbee25bb2f352', '[\"*\"]', NULL, NULL, '2025-07-06 15:17:29', '2025-07-06 15:17:29'),
(24, 'App\\Models\\User', 19, 'auth_token', 'e8bc406e5352bf8beeae42eec3b1195cb428a9b6a1f3e40a3d5033f166a0f688', '[\"*\"]', '2025-07-06 15:45:21', NULL, '2025-07-06 15:18:17', '2025-07-06 15:45:21'),
(25, 'App\\Models\\User', 20, 'auth_token', 'c0326af328f97dcd7aca4b25ab644c193d04fe57b1d958ab17b107dd34e38699', '[\"*\"]', NULL, NULL, '2025-07-06 15:46:12', '2025-07-06 15:46:12'),
(26, 'App\\Models\\User', 20, 'auth_token', '84a30a60281c675a047cd4056e73f03d604d5d07979c964293a9de32a239dad6', '[\"*\"]', '2025-07-06 16:36:31', NULL, '2025-07-06 15:46:31', '2025-07-06 16:36:31'),
(27, 'App\\Models\\User', 21, 'auth_token', '49117851d810b0c003b27aadbcb0cd0d5524c37a901fc1427f774e2616a6cf6f', '[\"*\"]', NULL, NULL, '2025-07-06 16:42:41', '2025-07-06 16:42:41'),
(28, 'App\\Models\\User', 21, 'auth_token', 'f6b0ab71e8e22b3e64f9c02f8a648149571fc6f7365a767917059c0c97b97d44', '[\"*\"]', '2025-07-06 16:44:10', NULL, '2025-07-06 16:43:10', '2025-07-06 16:44:10'),
(29, 'App\\Models\\User', 22, 'auth_token', '9fdf0627d648c7702955bbb65521da77395f9ebe76ff751750f14ddb37f1dc4c', '[\"*\"]', NULL, NULL, '2025-07-06 16:46:51', '2025-07-06 16:46:51'),
(30, 'App\\Models\\User', 22, 'auth_token', '3bf9fe899a1f4100a00ff7c86a82317eaa93493a8858f30d3c897d02a773e12d', '[\"*\"]', '2025-07-06 16:48:30', NULL, '2025-07-06 16:46:52', '2025-07-06 16:48:30'),
(31, 'App\\Models\\User', 22, 'auth_token', 'ad601b4211da4446a537034ae26a347348c8480c42482fc257921465f11e6411', '[\"*\"]', '2025-07-06 17:44:12', NULL, '2025-07-06 17:44:04', '2025-07-06 17:44:12'),
(32, 'App\\Models\\User', 22, 'auth_token', 'd49daadde1c67fccabe4febcfe7ef69ee77922b76474b073cbdcefab73726caf', '[\"*\"]', NULL, NULL, '2025-07-06 17:44:06', '2025-07-06 17:44:06'),
(33, 'App\\Models\\User', 22, 'auth_token', 'cafdd474dbc81a5990e85c22d22aaa2685e99b4265c116cd4783f5263c447bcf', '[\"*\"]', NULL, NULL, '2025-07-06 17:44:07', '2025-07-06 17:44:07'),
(34, 'App\\Models\\User', 22, 'auth_token', '05fbe165c6f8036e33bcf7658b06ea17f074132a12702c0e1cb74a0f49f98e0c', '[\"*\"]', NULL, NULL, '2025-07-06 17:44:08', '2025-07-06 17:44:08'),
(35, 'App\\Models\\User', 22, 'auth_token', 'bdd829634bd3821f2ed017e8f9e94b039fd71ffaca9a840f1bf22e515949eca0', '[\"*\"]', NULL, NULL, '2025-07-06 17:44:09', '2025-07-06 17:44:09'),
(36, 'App\\Models\\User', 22, 'auth_token', '70784a43ff340cb82e4d35867ccaed47baed1ee424b0db236e3da0e2258ae275', '[\"*\"]', '2025-07-06 17:44:42', NULL, '2025-07-06 17:44:11', '2025-07-06 17:44:42'),
(37, 'App\\Models\\User', 22, 'auth_token', '0a36d2e2d526e34403972ee3a1faeaa5a0cf93aac6a825d9c00753c550acb1eb', '[\"*\"]', '2025-07-06 17:51:26', NULL, '2025-07-06 17:49:44', '2025-07-06 17:51:26'),
(38, 'App\\Models\\User', 23, 'auth_token', 'de4cb7bf3f368151610989872849ebe55acaef217c60eee782afcfa9b21e34af', '[\"*\"]', NULL, NULL, '2025-07-06 17:55:19', '2025-07-06 17:55:19'),
(39, 'App\\Models\\User', 23, 'auth_token', '8ee26098ba0a635e4c4893d7fe574eab98fd2ea2fb4b4fa794bbfbdfb27d5838', '[\"*\"]', '2025-07-06 18:15:51', NULL, '2025-07-06 17:55:39', '2025-07-06 18:15:51'),
(40, 'App\\Models\\User', 22, 'auth_token', '6f39e9f68072539ad08b5db6b55658c81f861d88b880cd0d7f27ed745925e31b', '[\"*\"]', '2025-07-06 18:27:34', NULL, '2025-07-06 18:17:02', '2025-07-06 18:27:34'),
(41, 'App\\Models\\User', 23, 'auth_token', 'b0b3fd3419b80725966a71edb004d8cbf0ca5248ef3772a8ba02408b7be2fe06', '[\"*\"]', '2025-07-06 18:43:02', NULL, '2025-07-06 18:29:48', '2025-07-06 18:43:02'),
(42, 'App\\Models\\User', 22, 'auth_token', '20e0918035be7f065b0d96a80d1726766c4a1d3a24a57f92bdcf4d86ea56f679', '[\"*\"]', '2025-07-06 18:45:15', NULL, '2025-07-06 18:43:30', '2025-07-06 18:45:15'),
(43, 'App\\Models\\User', 24, 'auth_token', 'bfe592dcdf439f22b695d1c879bf4b9b82504351d997164c7e45a58ce714285a', '[\"*\"]', NULL, NULL, '2025-07-06 18:49:19', '2025-07-06 18:49:19'),
(44, 'App\\Models\\User', 24, 'auth_token', 'd4e62ed375f7bc894733b99a9a8bc8fdd74a94aae0f0b13ba4d5cc5ac37e5da6', '[\"*\"]', '2025-07-06 18:50:25', NULL, '2025-07-06 18:49:20', '2025-07-06 18:50:25'),
(45, 'App\\Models\\User', 24, 'auth_token', '50e4e0311df1aca3b6e9757276620d3c997b1ca986b96d866370b9a52ae766db', '[\"*\"]', '2025-07-06 20:30:38', NULL, '2025-07-06 18:50:46', '2025-07-06 20:30:38'),
(46, 'App\\Models\\User', 24, 'auth_token', '29c0b87af1fa3ec4370c7a84d58212b81ec3d635fd1421bf0a3a2e57bda7b050', '[\"*\"]', '2025-07-23 10:45:43', NULL, '2025-07-23 10:45:37', '2025-07-23 10:45:43'),
(47, 'App\\Models\\User', 24, 'auth_token', '89d9da893065741d1bce690c6b08f39e3a8f120023674b32965dccd58d9a11c4', '[\"*\"]', NULL, NULL, '2025-07-23 10:45:40', '2025-07-23 10:45:40'),
(48, 'App\\Models\\User', 24, 'auth_token', 'ec245bb1ed02ee2862ed4317cf28d74a3660d3171ce08cc25e2ba6af1c1984d0', '[\"*\"]', NULL, NULL, '2025-07-23 10:45:41', '2025-07-23 10:45:41'),
(49, 'App\\Models\\User', 24, 'auth_token', '1819a04b175b06629995eee7fd3d24ccc316818e8a3662ea1523d7364075a06a', '[\"*\"]', NULL, NULL, '2025-07-23 10:45:42', '2025-07-23 10:45:42'),
(50, 'App\\Models\\User', 24, 'auth_token', '7dcdbed06599350605d798eb261d7084180a6fd35633778fa11f5911a11878f5', '[\"*\"]', '2025-07-23 11:28:43', NULL, '2025-07-23 10:46:59', '2025-07-23 11:28:43'),
(51, 'App\\Models\\User', 23, 'auth_token', '98e55b2deb891aa73b6262e31ccb3c1ae5f9825b495680eb07fc9ce38db83bfa', '[\"*\"]', '2025-07-23 11:30:24', NULL, '2025-07-23 11:30:07', '2025-07-23 11:30:24'),
(52, 'App\\Models\\User', 24, 'auth_token', 'cd1accc96eaabae30fbeebfbe31e258955e15df55c88ec14c9e8f5713474ce45', '[\"*\"]', '2025-07-23 11:47:32', NULL, '2025-07-23 11:46:01', '2025-07-23 11:47:32'),
(53, 'App\\Models\\User', 23, 'auth_token', '49fd4414a0c211f41dc00a75cf38f27c19d46b93bdbb4428ceada7a0c92d579c', '[\"*\"]', '2025-07-23 13:55:32', NULL, '2025-07-23 11:48:33', '2025-07-23 13:55:32'),
(54, 'App\\Models\\User', 24, 'auth_token', 'be4ca37bfff87597f0029386a16639fa232e41b58e46d4b512b234556fcf0454', '[\"*\"]', '2025-07-23 13:56:28', NULL, '2025-07-23 13:55:51', '2025-07-23 13:56:28'),
(55, 'App\\Models\\User', 23, 'auth_token', 'ca6018e9bb4606861569b1a37f8580648fcc99ef23e862e76cb548b623a4d096', '[\"*\"]', '2025-07-23 14:25:10', NULL, '2025-07-23 14:23:02', '2025-07-23 14:25:10'),
(56, 'App\\Models\\User', 24, 'auth_token', '4ae026b3856da698244c3ae8879f7c9d233daaf774f3585a15b774cd6532667a', '[\"*\"]', '2025-07-23 14:27:16', NULL, '2025-07-23 14:26:15', '2025-07-23 14:27:16'),
(57, 'App\\Models\\User', 24, 'auth_token', 'e27f565c4e0daf3138f05eed13a2b2145114bbe2dfb1cb6b56296d2ab251db63', '[\"*\"]', '2025-07-23 14:41:32', NULL, '2025-07-23 14:40:37', '2025-07-23 14:41:32'),
(58, 'App\\Models\\User', 23, 'auth_token', '9e5081d68c722f87c49ab29c07f015e21d67f71081e540509d98bed022710438', '[\"*\"]', '2025-07-23 14:57:57', NULL, '2025-07-23 14:42:07', '2025-07-23 14:57:57'),
(59, 'App\\Models\\User', 23, 'auth_token', '438ae22afa2467a3300a10876d01c127b51c8a3af05a9cbf602cc925c17b8bbc', '[\"*\"]', '2025-07-23 15:04:07', NULL, '2025-07-23 14:58:36', '2025-07-23 15:04:07'),
(60, 'App\\Models\\User', 23, 'auth_token', '2d85892c7ed81d14a0af1dc0a9b6f58b06a79e0dd81063fd1a12986d84925f14', '[\"*\"]', '2025-07-23 15:51:15', NULL, '2025-07-23 15:51:14', '2025-07-23 15:51:15'),
(61, 'App\\Models\\User', 24, 'auth_token', '84d24d7470532a35f2e30e278e47fcd89803cdadfc7768a4d003bcb1fa79d0eb', '[\"*\"]', '2025-07-23 15:54:08', NULL, '2025-07-23 15:54:01', '2025-07-23 15:54:08'),
(62, 'App\\Models\\User', 23, 'auth_token', '0a42886edd109e7d8a3d96de4897a4fef1d4824e61d1c6e04bd07ada4c5bbb83', '[\"*\"]', '2025-07-23 15:55:58', NULL, '2025-07-23 15:55:35', '2025-07-23 15:55:58'),
(63, 'App\\Models\\User', 24, 'auth_token', '2bd0c666e6e02cd2e1d2c16032da14f1e2872dc4d2cb82758e40a20c8e093f7d', '[\"*\"]', NULL, NULL, '2025-07-23 20:20:48', '2025-07-23 20:20:48'),
(64, 'App\\Models\\User', 24, 'auth_token', '871111fdb5ae3c4cb84e7b0610c6cfe25e81ad55ee66417a6bea6a576061d913', '[\"*\"]', '2025-07-26 12:46:21', NULL, '2025-07-23 21:10:44', '2025-07-26 12:46:21'),
(65, 'App\\Models\\User', 24, 'auth_token', '974fbda626f945ea600387bf242479b48daa5d51e30c0163964c6ed1b8360f63', '[\"*\"]', '2025-07-23 21:30:07', NULL, '2025-07-23 21:29:32', '2025-07-23 21:30:07'),
(66, 'App\\Models\\User', 24, 'auth_token', 'cf104a173e850f4d0a6446bb6566881f43da80d8fe0c1f1ff728d5d603780983', '[\"*\"]', '2025-07-23 22:46:14', NULL, '2025-07-23 22:46:09', '2025-07-23 22:46:14'),
(67, 'App\\Models\\User', 24, 'auth_token', '16b6ff822d77e9e8adfc85d86a3e9263d1a26137bdd5b473a09443c746b021ee', '[\"*\"]', '2025-07-23 22:49:35', NULL, '2025-07-23 22:46:13', '2025-07-23 22:49:35'),
(68, 'App\\Models\\User', 24, 'auth_token', '58131b0c48594b3acfab5f4f6deaa25c22ea45721ecc4bce56fdd7b4b2d1effb', '[\"*\"]', NULL, NULL, '2025-07-23 22:52:55', '2025-07-23 22:52:55'),
(69, 'App\\Models\\User', 24, 'auth_token', '0d847aecdff5418953824daffe490133ff08b0cee33d3b11824c2f074d294b1b', '[\"*\"]', NULL, NULL, '2025-07-23 22:53:03', '2025-07-23 22:53:03'),
(70, 'App\\Models\\User', 24, 'auth_token', 'cc2528dde5068ecc87c59e657ddde2b7343bbc2d82440e73829b699c3acf45d8', '[\"*\"]', NULL, NULL, '2025-07-23 22:53:06', '2025-07-23 22:53:06'),
(71, 'App\\Models\\User', 24, 'auth_token', 'a404287dcaeae39ffefad45eb4e55645088d483fc0b77afce22244a6a637a4e8', '[\"*\"]', NULL, NULL, '2025-07-23 22:53:08', '2025-07-23 22:53:08'),
(72, 'App\\Models\\User', 24, 'auth_token', '15c4f7d0841750fd00d26fba426c83c5286a3de5928cd14b01a707ed2497409a', '[\"*\"]', '2025-07-24 08:06:59', NULL, '2025-07-23 23:09:03', '2025-07-24 08:06:59'),
(73, 'App\\Models\\User', 23, 'auth_token', '17edac158fd704fc91438ec14d8ae03d1903afd4247ccfbd964ad13e2bc74f17', '[\"*\"]', '2025-07-24 08:07:14', NULL, '2025-07-24 08:07:13', '2025-07-24 08:07:14'),
(74, 'App\\Models\\User', 24, 'auth_token', '32f2a3e97b208f2f97072f25f79abf376c8499fa503f3f1313aca61d205a09da', '[\"*\"]', '2025-07-24 08:49:12', NULL, '2025-07-24 08:07:33', '2025-07-24 08:49:12'),
(75, 'App\\Models\\User', 25, 'auth_token', 'd4f41ecdb7fff161632799dd5c4de69ced5df15291277677a50f70288a8c142d', '[\"*\"]', NULL, NULL, '2025-07-24 09:07:15', '2025-07-24 09:07:15'),
(76, 'App\\Models\\User', 25, 'auth_token', '1717cc3902ad007d972113fb31603ec236562d4a80274a98dfbeb9ead97a37ff', '[\"*\"]', '2025-07-24 09:08:25', NULL, '2025-07-24 09:07:16', '2025-07-24 09:08:25'),
(77, 'App\\Models\\User', 24, 'auth_token', '6f8249565c477cbe932c8149b2ebe57a22f6bbc3a1f55d4dab6c89851964efa3', '[\"*\"]', '2025-07-24 09:09:11', NULL, '2025-07-24 09:09:10', '2025-07-24 09:09:11'),
(78, 'App\\Models\\User', 26, 'auth_token', '0920c559fb37f46d77c41ad108c03a5a539aaf464c982aa29acaff4eff727b1e', '[\"*\"]', NULL, NULL, '2025-07-24 09:10:07', '2025-07-24 09:10:07'),
(79, 'App\\Models\\User', 26, 'auth_token', 'f3d5402799eefaa24d3bd2c8cc6b3fd2a076203efe475430493a2bbb0aa164f0', '[\"*\"]', '2025-07-24 09:10:37', NULL, '2025-07-24 09:10:08', '2025-07-24 09:10:37'),
(80, 'App\\Models\\User', 26, 'auth_token', '6ead9f94cbc4772f6f0bc286ea215a388705d3f9d620b0e5b72ba678e9ccfad0', '[\"*\"]', '2025-07-24 09:11:01', NULL, '2025-07-24 09:10:47', '2025-07-24 09:11:01'),
(81, 'App\\Models\\User', 23, 'auth_token', 'd3de68750aa248aebc5426be83e53fe44c227628d4d02ad8f54b445ac0cd63ba', '[\"*\"]', '2025-07-24 09:12:00', NULL, '2025-07-24 09:11:58', '2025-07-24 09:12:00'),
(82, 'App\\Models\\User', 26, 'auth_token', '2045c4044e6b574cb2171edb58e49ce1b38ef40136ce2456543e54b99cc3d996', '[\"*\"]', '2025-07-24 09:22:33', NULL, '2025-07-24 09:12:39', '2025-07-24 09:22:33'),
(83, 'App\\Models\\User', 23, 'auth_token', 'caf9019a6c3c6bf4a06154369fed824f12c780f42b48b5e0dea64e662eda1c12', '[\"*\"]', '2025-07-24 09:24:50', NULL, '2025-07-24 09:23:56', '2025-07-24 09:24:50'),
(84, 'App\\Models\\User', 26, 'auth_token', 'ec77a2ca0ae538b6a164afd4d49e4f99b14d34f8e8e517094c69f984fb6ffc84', '[\"*\"]', '2025-07-28 10:50:45', NULL, '2025-07-24 09:25:22', '2025-07-28 10:50:45'),
(85, 'App\\Models\\User', 24, 'auth_token', 'f241f85ff58f9c6ef50a8205a816ebea493fbe52b274099da0f3eccd6134929c', '[\"*\"]', '2025-07-28 15:27:50', NULL, '2025-07-28 11:35:17', '2025-07-28 15:27:50'),
(86, 'App\\Models\\User', 24, 'auth_token', '5b3c4681da0458c7f06298cf595fd722a48639b2a11f4fe301fe7e6396264f34', '[\"*\"]', '2025-07-28 14:47:22', NULL, '2025-07-28 14:45:49', '2025-07-28 14:47:22'),
(87, 'App\\Models\\User', 30, 'auth_token', '53ece3bfdee9493087e0c4b256eee60dd6122465247c03db2398fef8b481cde1', '[\"*\"]', NULL, NULL, '2025-07-28 15:29:16', '2025-07-28 15:29:16'),
(88, 'App\\Models\\User', 30, 'auth_token', '1e819c04572f3432e2624105f5d4d223b951a9c7b26bc9500ba5f4a14c7f0422', '[\"*\"]', '2025-07-28 15:31:01', NULL, '2025-07-28 15:29:17', '2025-07-28 15:31:01'),
(89, 'App\\Models\\User', 24, 'auth_token', '564c2eb27ff73b72a170d301ba3dff7a8d7322a5787d8bde7eab7a80199164ec', '[\"*\"]', '2025-07-29 00:22:00', NULL, '2025-07-28 15:58:38', '2025-07-29 00:22:00'),
(90, 'App\\Models\\Admin', 1, 'admin-token', '5b45798870420ef5ef547df3fe3c191b7a8b1971cc96c17c911de6eaaf4471ad', '[\"*\"]', NULL, NULL, '2025-07-29 00:53:14', '2025-07-29 00:53:14'),
(91, 'App\\Models\\Admin', 1, 'admin-token', '4af64938406c7348f1d689f44dc042dc0c0fa9c158e7df05e11868f31cec895c', '[\"*\"]', NULL, NULL, '2025-07-29 00:54:00', '2025-07-29 00:54:00'),
(92, 'App\\Models\\Admin', 1, 'admin-token', '73d3f07e0a9a9d3d85bd98f5ef5afd939ae06574fea4045cf1a7572fd67a7721', '[\"*\"]', NULL, NULL, '2025-07-29 00:54:10', '2025-07-29 00:54:10'),
(93, 'App\\Models\\Admin', 1, 'admin-token', '8556eb9c1e2dd01bd32df38699539b4864c564e3593a4e1d62f4299443aa8ae3', '[\"*\"]', NULL, NULL, '2025-07-29 00:54:30', '2025-07-29 00:54:30'),
(94, 'App\\Models\\Admin', 1, 'admin-token', '5fddcea9ceb30eb424af1a52a0b1052d87bfe5bfb5ec77585369e867d8c97b48', '[\"*\"]', NULL, NULL, '2025-07-29 00:54:45', '2025-07-29 00:54:45'),
(95, 'App\\Models\\Admin', 1, 'admin-token', '3cb2ca8242876d6ab608c49d25540a3d9dfde1a5bbc4c7f4507a172c7ed1ccaa', '[\"*\"]', NULL, NULL, '2025-07-29 00:55:04', '2025-07-29 00:55:04'),
(96, 'App\\Models\\Admin', 1, 'admin-token', '175962f30d0785a5b897c6620aeb760f53ba8fdf2408ea2616c9a0039a63e959', '[\"*\"]', NULL, NULL, '2025-07-29 01:11:20', '2025-07-29 01:11:20'),
(97, 'App\\Models\\Admin', 1, 'admin-token', 'a648e38797c9c6eddb691b1d44e53859b65a4b9d844424e6c2cccf0d92713bb0', '[\"*\"]', NULL, NULL, '2025-07-29 01:42:45', '2025-07-29 01:42:45'),
(98, 'App\\Models\\Admin', 1, 'admin-token', '2cf8c60e72e78aa5e324073ca995648d49e0d53ee1aace390907567bd98a12d1', '[\"*\"]', NULL, NULL, '2025-07-29 01:52:03', '2025-07-29 01:52:03'),
(99, 'App\\Models\\Admin', 1, 'admin-token', '9a6d0a6290d9d7600ef3aee50ccf3812f5b03b9abf70a67cb5ee2d87801837cf', '[\"*\"]', '2025-07-29 15:48:16', NULL, '2025-07-29 06:53:57', '2025-07-29 15:48:16'),
(100, 'App\\Models\\Admin', 1, 'admin-token', '2101685da64e90ed593cd155d6ecb4eb8ed87109c1de7bb46f46f12d7264ef89', '[\"*\"]', '2025-07-29 08:17:59', NULL, '2025-07-29 07:37:27', '2025-07-29 08:17:59'),
(101, 'App\\Models\\Admin', 1, 'admin-token', 'f610a9c2f3279705aab2830f80b45d10de79876e55ecbd7549d689eeae40948a', '[\"*\"]', '2025-07-29 23:07:56', NULL, '2025-07-29 08:18:57', '2025-07-29 23:07:56'),
(102, 'App\\Models\\Admin', 1, 'admin-token', '459135b512efdb3b0ba9b6a696476d48df43337c302cc9f2c3af876e180a1081', '[\"*\"]', '2025-07-29 16:32:55', NULL, '2025-07-29 15:48:26', '2025-07-29 16:32:55'),
(103, 'App\\Models\\Admin', 1, 'admin-token', 'fa824a0e365e475dd4848e9b5e5a9d45cda71a81dff54b6aaffffdd9d0cf4b2d', '[\"*\"]', '2025-07-29 16:37:23', NULL, '2025-07-29 16:33:30', '2025-07-29 16:37:23'),
(106, 'App\\Models\\User', 24, 'auth_token', '805cb13e84b24e7f2b003d2a5971778d23a075b77351d474a99f6a4a9d6c6b2b', '[\"*\"]', '2025-07-29 17:56:14', NULL, '2025-07-29 17:56:12', '2025-07-29 17:56:14'),
(109, 'App\\Models\\User', 31, 'auth_token', '01234459966a6c17c0911ec3f29436eb5f9579461d335d7ff287a9e03752db7b', '[\"*\"]', '2025-08-01 08:05:44', NULL, '2025-08-01 08:04:08', '2025-08-01 08:05:44'),
(110, 'App\\Models\\User', 32, 'auth_token', '5a903cd77e8c3309b7e085e3d3f1270285d14a737c6c7e1ea03bbb96be6b2837', '[\"*\"]', NULL, NULL, '2025-08-01 08:13:26', '2025-08-01 08:13:26'),
(111, 'App\\Models\\User', 32, 'auth_token', '94498b85e8de362367ead1a10417612e91fe1c5858379aa62d92fee5c2dd0658', '[\"*\"]', '2025-08-01 08:14:49', NULL, '2025-08-01 08:13:53', '2025-08-01 08:14:49'),
(112, 'App\\Models\\User', 33, 'auth_token', '4ec6a647c4a46d81a4410bc8b4a365cc580c617783fa3b01b4bc847f9c9bb055', '[\"*\"]', '2025-08-01 19:41:07', NULL, '2025-08-01 19:32:02', '2025-08-01 19:41:07'),
(113, 'App\\Models\\User', 34, 'auth_token', '14bb4979cc679a75939299c837e5aadc7e889feb305497a1585a10e490f3aa6a', '[\"*\"]', NULL, NULL, '2025-08-01 20:05:29', '2025-08-01 20:05:29'),
(114, 'App\\Models\\User', 34, 'auth_token', '03a77af3b61f595ab3ccceaef54f410a1dd60be8f6a3024fef3838cd833868ad', '[\"*\"]', NULL, NULL, '2025-08-01 20:05:52', '2025-08-01 20:05:52'),
(115, 'App\\Models\\User', 34, 'auth_token', '0a9044497576a075ecef0c84cd0b33f2f143056e3ded94205b4f3abd76a3209b', '[\"*\"]', '2025-08-01 21:11:52', NULL, '2025-08-01 20:06:19', '2025-08-01 21:11:52'),
(116, 'App\\Models\\User', 35, 'auth_token', 'f8af44dca2fd8437b40a62d8213d53b013072c81f09071ff829439b125ecdef4', '[\"*\"]', NULL, NULL, '2025-08-01 21:18:39', '2025-08-01 21:18:39'),
(117, 'App\\Models\\User', 35, 'auth_token', 'bb351dff783cb3e2e390b93eaa49de8d4e15788c4798c21efdf07dd5e946a0ac', '[\"*\"]', '2025-08-01 21:40:50', NULL, '2025-08-01 21:19:15', '2025-08-01 21:40:50'),
(118, 'App\\Models\\User', 35, 'auth_token', '1210a3819c7c1847c42451931037bc727d129eabdd101fd14b6d541d33021602', '[\"*\"]', '2025-08-01 21:43:08', NULL, '2025-08-01 21:42:09', '2025-08-01 21:43:08'),
(119, 'App\\Models\\User', 36, 'auth_token', 'b59e8bb819752620c14afde05ebe45c3467eb5f99c75dc25293a3312ea76452e', '[\"*\"]', '2025-08-01 22:10:07', NULL, '2025-08-01 21:44:49', '2025-08-01 22:10:07'),
(120, 'App\\Models\\User', 37, 'auth_token', '26528f3ed7d198964dc6977ad5e10fd8948a4b39fbb9d8c495d477c9439cebfa', '[\"*\"]', '2025-08-01 23:12:31', NULL, '2025-08-01 23:05:21', '2025-08-01 23:12:31'),
(121, 'App\\Models\\User', 37, 'auth_token', 'f69db8d6f93a841aab7f4d2fdd8d7f5ae685d51a596a9b6b6385fce665ab24ae', '[\"*\"]', '2025-08-01 23:15:12', NULL, '2025-08-01 23:14:18', '2025-08-01 23:15:12'),
(122, 'App\\Models\\User', 38, 'auth_token', '8937f4bc61a256198e07fab6b95ed5b820ea2722a9b258333b0bf1531f1e054f', '[\"*\"]', '2025-08-01 23:35:12', NULL, '2025-08-01 23:34:05', '2025-08-01 23:35:12'),
(123, 'App\\Models\\User', 39, 'auth_token', '88845261109c2b998e5b23491e4ba4a50c8946117b029295ad0dde1d06fd4164', '[\"*\"]', '2025-08-01 23:58:01', NULL, '2025-08-01 23:41:28', '2025-08-01 23:58:01'),
(124, 'App\\Models\\User', 40, 'auth_token', '1cc64460048b2e15f406d5cce5de355095df6da1c1f8ce16bc83c839d1e5db79', '[\"*\"]', NULL, NULL, '2025-08-02 00:02:15', '2025-08-02 00:02:15'),
(125, 'App\\Models\\User', 40, 'auth_token', 'b0b67b3b70e0d2a30a3016eadb1e05d9fbd8f5ad57f89bafc5149967c19312cf', '[\"*\"]', '2025-08-02 00:48:46', NULL, '2025-08-02 00:02:16', '2025-08-02 00:48:46'),
(126, 'App\\Models\\User', 41, 'auth_token', 'b99d8c3a442313b4dda8d26c10e7eda0cc1748e1dd14c2cc3de4e914bb441a5f', '[\"*\"]', NULL, NULL, '2025-08-02 00:55:26', '2025-08-02 00:55:26'),
(127, 'App\\Models\\User', 41, 'auth_token', '268370070f0980d903480a010b17c34aa690470970862db521d5e1c12ad03580', '[\"*\"]', '2025-08-02 01:05:33', NULL, '2025-08-02 00:55:27', '2025-08-02 01:05:33'),
(128, 'App\\Models\\User', 42, 'auth_token', '6ef430a28fe6c108f3485b19a9a79ace581cb2c42b007b619cff7b1bb37f6815', '[\"*\"]', NULL, NULL, '2025-08-02 01:26:06', '2025-08-02 01:26:06'),
(129, 'App\\Models\\User', 42, 'auth_token', '386a5f33ed4af93b0c69a4b332e0bc520992e2a14a23bc1c067316f5c7183b3f', '[\"*\"]', '2025-08-02 01:26:22', NULL, '2025-08-02 01:26:07', '2025-08-02 01:26:22'),
(130, 'App\\Models\\User', 43, 'auth_token', 'baab9dcf797c3a2dbcc8780e47862793ef661450297a5dec81d688783457ccb2', '[\"*\"]', NULL, NULL, '2025-08-02 01:30:13', '2025-08-02 01:30:13'),
(131, 'App\\Models\\User', 43, 'auth_token', '1f88b56cb6a082db8d7399e6b0c4b42a4a51b661ba0bc42ccc0306240b442dde', '[\"*\"]', '2025-08-02 01:30:37', NULL, '2025-08-02 01:30:14', '2025-08-02 01:30:37'),
(132, 'App\\Models\\User', 44, 'auth_token', '2f0afb2c7f2c3a55b8509d9e148dba143e83cca6269c3366f5593769f8aae501', '[\"*\"]', NULL, NULL, '2025-08-02 01:37:21', '2025-08-02 01:37:21'),
(133, 'App\\Models\\User', 44, 'auth_token', '75f0213a7f28b7ff8fb837a25a6b601fa343908f1ec0d44eca890dc0196a9f2c', '[\"*\"]', '2025-08-02 01:37:43', NULL, '2025-08-02 01:37:23', '2025-08-02 01:37:43'),
(134, 'App\\Models\\User', 44, 'auth_token', '5ca4fa604adf412abecf353ba70b96fc388f3f63bb7a3d2715650f5b7676bbc6', '[\"*\"]', '2025-08-02 01:39:18', NULL, '2025-08-02 01:37:59', '2025-08-02 01:39:18'),
(135, 'App\\Models\\User', 45, 'auth_token', '722f92bc2023312ffca8fe3abaf04faa757d99363b44592cf9db84f997cd8399', '[\"*\"]', NULL, NULL, '2025-08-02 01:40:42', '2025-08-02 01:40:42'),
(136, 'App\\Models\\User', 45, 'auth_token', '5fd45a2d3e4dfaeae2abd1f3b6a3a94603855b5d8d8f05293380f8254ba49286', '[\"*\"]', '2025-08-02 01:41:02', NULL, '2025-08-02 01:40:44', '2025-08-02 01:41:02'),
(137, 'App\\Models\\User', 46, 'auth_token', '2045ad92db8a393b1dc88b778707edafe19c37ab7fd7ec96e607de32a50a7a01', '[\"*\"]', NULL, NULL, '2025-08-02 12:11:39', '2025-08-02 12:11:39'),
(138, 'App\\Models\\User', 46, 'auth_token', '3cb77e2a06421d5d0405a54501bdd1e2c388f22a539febfc57c0be8fc1370e61', '[\"*\"]', '2025-08-02 12:12:10', NULL, '2025-08-02 12:11:41', '2025-08-02 12:12:10'),
(139, 'App\\Models\\User', 47, 'auth_token', 'c0cfd81b6ab970d7c4fa10c6578075b1d1d9a03440f42650aafef8692199e0c0', '[\"*\"]', NULL, NULL, '2025-08-02 13:58:54', '2025-08-02 13:58:54'),
(140, 'App\\Models\\User', 47, 'auth_token', 'b504e767a68b62cf5d60d9114cdba077a7d9c8ddbb361812c9c9b062242da045', '[\"*\"]', '2025-08-02 13:59:25', NULL, '2025-08-02 13:58:55', '2025-08-02 13:59:25'),
(141, 'App\\Models\\User', 47, 'auth_token', '8f85d5fe3218c5e6ddf705bb47b2b0a11df7ceb485a9160653b764d8b608d0d9', '[\"*\"]', '2025-08-02 18:04:57', NULL, '2025-08-02 16:42:47', '2025-08-02 18:04:57'),
(142, 'App\\Models\\User', 24, 'auth_token', 'fd2b0877fb32961f3e4d5a73969bec1fcd560c0754b7e2505fc83ae3e91dc2a5', '[\"*\"]', '2025-08-02 18:06:03', NULL, '2025-08-02 18:06:01', '2025-08-02 18:06:03'),
(143, 'App\\Models\\User', 23, 'auth_token', '9b77604667b150c061678c82df93563f6421b8ada6d83776f7aed105b07733e2', '[\"*\"]', '2025-08-02 18:07:25', NULL, '2025-08-02 18:06:42', '2025-08-02 18:07:25'),
(144, 'App\\Models\\User', 24, 'auth_token', '63024c43c907479b054dce8773c55d36c7416fc63d44afa9d2367a96c05e0a38', '[\"*\"]', '2025-08-02 21:59:22', NULL, '2025-08-02 18:07:40', '2025-08-02 21:59:22'),
(145, 'App\\Models\\User', 24, 'auth_token', 'd66424d41ffdc2027278c07195c5232eb248a90fa2f9e94a006963ad4b025f22', '[\"*\"]', '2025-08-02 19:28:16', NULL, '2025-08-02 19:18:05', '2025-08-02 19:28:16'),
(146, 'App\\Models\\User', 24, 'auth_token', '00482429670fc7dca8187e31c4f0c1615aa66c3f2348ae90680717385e6e153a', '[\"*\"]', '2025-08-02 21:12:50', NULL, '2025-08-02 20:59:05', '2025-08-02 21:12:50'),
(147, 'App\\Models\\User', 47, 'auth_token', '3aa1b09ef21f7c54838835c663d567737c841838bdbb158c53cacf524780ea5e', '[\"*\"]', '2025-08-02 22:22:04', NULL, '2025-08-02 22:21:51', '2025-08-02 22:22:04'),
(148, 'App\\Models\\User', 47, 'auth_token', '86d23f9fd774d5730fb69153d35541083d252d4768fd3ff19c8e4c6082009573', '[\"*\"]', NULL, NULL, '2025-08-02 22:21:57', '2025-08-02 22:21:57'),
(149, 'App\\Models\\User', 47, 'auth_token', 'e5b3d7e350f63678b67b8b0d888e3f07aeb092a1e1845222f5b65c96dda14c89', '[\"*\"]', NULL, NULL, '2025-08-02 22:21:59', '2025-08-02 22:21:59'),
(150, 'App\\Models\\User', 47, 'auth_token', '34e3a53737359464c9c8b59dfed80f218de9cc85fd3a7b4f5f09c9fb7d0a44f6', '[\"*\"]', NULL, NULL, '2025-08-02 22:22:00', '2025-08-02 22:22:00'),
(151, 'App\\Models\\User', 47, 'auth_token', '31570e9e34671c54fada4762c9bc90904e330f402f08a324729fa9411142a185', '[\"*\"]', NULL, NULL, '2025-08-02 22:22:01', '2025-08-02 22:22:01'),
(152, 'App\\Models\\User', 47, 'auth_token', '67b9d14e9cd2c34bc49f83e0b124cf857eec2af186635331bfd6cfce10e69f04', '[\"*\"]', '2025-08-02 22:22:12', NULL, '2025-08-02 22:22:02', '2025-08-02 22:22:12'),
(153, 'App\\Models\\User', 48, 'auth_token', '44db4a33284bda9ecaa94e85ca0534764eaa4ce1c891e4cae068dfa46aba8d23', '[\"*\"]', NULL, NULL, '2025-08-02 22:22:52', '2025-08-02 22:22:52'),
(154, 'App\\Models\\User', 48, 'auth_token', '504b61ae48e58b714a63291c9703fadd0fd57a1178401d6a61e3dc9ea68c66c0', '[\"*\"]', '2025-08-02 22:23:25', NULL, '2025-08-02 22:22:53', '2025-08-02 22:23:25'),
(155, 'App\\Models\\User', 48, 'auth_token', '92620ac269449205622f5a84d18903be1877eb94304d736e5867282338a32938', '[\"*\"]', '2025-08-02 22:26:08', NULL, '2025-08-02 22:23:32', '2025-08-02 22:26:08'),
(156, 'App\\Models\\Admin', 1, 'admin-token', '8b20be546f2fe5b61b692ead84408ccbd361d571ef41d55bea07f46ae9f7bfe8', '[\"*\"]', '2025-08-03 08:26:01', NULL, '2025-08-03 08:25:30', '2025-08-03 08:26:01'),
(157, 'App\\Models\\Admin', 1, 'admin-token', 'd73c6c1ba7924ecd046f49b4e50014d34d8949f02c954beed65663e839ea7df5', '[\"*\"]', '2025-08-03 08:29:52', NULL, '2025-08-03 08:27:19', '2025-08-03 08:29:52'),
(158, 'App\\Models\\User', 48, 'auth_token', '0c26d5781afb7afe3f6fac4379a48a84f8caadbbe5e1c148f2521064dc3e6141', '[\"*\"]', '2025-08-03 08:50:55', NULL, '2025-08-03 08:31:44', '2025-08-03 08:50:55'),
(159, 'App\\Models\\User', 48, 'auth_token', 'a9ac6208e121d1f33ec134d23a824b7148745532d0b5d567ac2f060f3142f919', '[\"*\"]', NULL, NULL, '2025-08-03 08:38:31', '2025-08-03 08:38:31'),
(160, 'App\\Models\\User', 47, 'auth_token', '486793597c5f0c7535d0115b0424e7d61021b97eaaa120226c9d730348a85e69', '[\"*\"]', '2025-08-03 08:52:46', NULL, '2025-08-03 08:51:51', '2025-08-03 08:52:46'),
(162, 'App\\Models\\Admin', 1, 'admin-token', '6ae5a5978fbcb8dcfeec6f485d09708b46f3004dc40df5297bf7b9bc15bd0ea5', '[\"*\"]', '2025-08-03 09:17:25', NULL, '2025-08-03 09:08:06', '2025-08-03 09:17:25'),
(163, 'App\\Models\\Admin', 1, 'admin-token', 'b463a6c4137cc00c17a8092be8ca229c42ae89df7e9e403d2ad7c13092f9525e', '[\"*\"]', '2025-08-04 07:08:31', NULL, '2025-08-03 09:22:43', '2025-08-04 07:08:31'),
(164, 'App\\Models\\User', 47, 'auth_token', '8468d2412e415b1af0e5cef23418131800045cc9e3348fa1fd160085c7304671', '[\"*\"]', '2025-08-03 15:06:38', NULL, '2025-08-03 09:23:17', '2025-08-03 15:06:38'),
(165, 'App\\Models\\User', 49, 'auth_token', '5266b6c6c7cf1ab902850d78f3246a9c6e6012a2ee92fdaa3aa0c2b4a4ac8471', '[\"*\"]', NULL, NULL, '2025-08-04 06:05:49', '2025-08-04 06:05:49'),
(166, 'App\\Models\\User', 49, 'auth_token', '7ca7a1eea50b6c11ec125928f28e314bb0810053694be4de19a7974916f67798', '[\"*\"]', '2025-08-04 06:06:12', NULL, '2025-08-04 06:05:51', '2025-08-04 06:06:12'),
(167, 'App\\Models\\User', 49, 'auth_token', 'c247a6a67bb6cc97db41e7441b86e24d8e01f6b98c04c406f39aa0881c8c5f9a', '[\"*\"]', '2025-08-04 06:08:49', NULL, '2025-08-04 06:08:12', '2025-08-04 06:08:49'),
(168, 'App\\Models\\User', 50, 'auth_token', '5f72d65d1ab3694f84700afad7f1a574b1776425c7997c5036b3efcfd60ab83a', '[\"*\"]', NULL, NULL, '2025-08-04 07:01:15', '2025-08-04 07:01:15'),
(169, 'App\\Models\\User', 50, 'auth_token', 'f47a296906f9047146a916c068cefd50c1b3fd7c7f1b415ac85efe960aa82f58', '[\"*\"]', '2025-08-04 07:02:04', NULL, '2025-08-04 07:01:17', '2025-08-04 07:02:04'),
(170, 'App\\Models\\User', 50, 'auth_token', '80dfa3e7259f3853f6a3d6d7cade5a28d613a3728ddb2970ffcac64cb9554cc7', '[\"*\"]', '2025-08-04 07:09:38', NULL, '2025-08-04 07:02:11', '2025-08-04 07:09:38'),
(171, 'App\\Models\\User', 50, 'auth_token', '6a51f21ae54acb273826c163c6a195af6465d2527be5c54bed2afca736288c39', '[\"*\"]', '2025-08-04 10:38:09', NULL, '2025-08-04 10:31:56', '2025-08-04 10:38:09'),
(172, 'App\\Models\\User', 50, 'auth_token', 'b06d9bf1fe988a85ed93aa2e1220a93a553bd5caa476a06cc95eac71dd717f50', '[\"*\"]', '2025-08-04 19:48:11', NULL, '2025-08-04 11:50:34', '2025-08-04 19:48:11'),
(173, 'App\\Models\\User', 50, 'auth_token', '649281d2e5c5c6ac554520255cf18b8c99737969da63739b0d9b753e7f74246d', '[\"*\"]', '2025-08-04 22:51:00', NULL, '2025-08-04 19:48:32', '2025-08-04 22:51:00'),
(174, 'App\\Models\\User', 50, 'auth_token', 'd897a53979e764d16e01d5151060a9471de49ebb884a2f125d351fca6650a365', '[\"*\"]', '2025-08-05 00:19:47', NULL, '2025-08-04 23:00:02', '2025-08-05 00:19:47'),
(175, 'App\\Models\\User', 50, 'auth_token', 'dc1a06c06f4a00e907e67bfad1b1af701c930cf223f95a7d5c83102cb661a69a', '[\"*\"]', NULL, NULL, '2025-08-05 00:27:34', '2025-08-05 00:27:34'),
(176, 'App\\Models\\User', 50, 'auth_token', '2072f9a1c32e9e9137603a344894e9ecbc2efd27849975c2c68e67e3c68c97ca', '[\"*\"]', '2025-08-05 01:05:22', NULL, '2025-08-05 01:03:38', '2025-08-05 01:05:22'),
(177, 'App\\Models\\User', 50, 'auth_token', '47030e8a5d55a05a2ab70a12e589539f8d20b7998fec2737e50f2722212ddf03', '[\"*\"]', '2025-08-05 01:10:10', NULL, '2025-08-05 01:08:54', '2025-08-05 01:10:10'),
(178, 'App\\Models\\User', 50, 'auth_token', '698dd767972225f7b61ee39c6ffbdd4e5c4d69985e7897622083720742934f59', '[\"*\"]', '2025-08-05 09:33:05', NULL, '2025-08-05 04:05:39', '2025-08-05 09:33:05'),
(179, 'App\\Models\\User', 50, 'auth_token', '52c4320973891731310db69ebee3f4e092468f6488acb17a76ab3ea5e07f06e0', '[\"*\"]', '2025-08-05 06:14:47', NULL, '2025-08-05 06:14:41', '2025-08-05 06:14:47'),
(180, 'App\\Models\\User', 50, 'auth_token', '6feded831fa797360ca3a759c05f085fb2a2a1514f17ef543f33e88fd817f1d2', '[\"*\"]', '2025-08-05 09:48:15', NULL, '2025-08-05 06:14:44', '2025-08-05 09:48:15'),
(181, 'App\\Models\\User', 50, 'auth_token', '3a1ccb3b7c48fe505bc2f1fb2fac9558e3f2d4291b60ff99e38dd85dc32daafa', '[\"*\"]', '2025-08-05 09:47:53', NULL, '2025-08-05 09:37:10', '2025-08-05 09:47:53'),
(182, 'App\\Models\\User', 50, 'auth_token', 'a9f9491d0644c2b559a4862b2d6bdede7f82115722b62dd5bb51130dad313e56', '[\"*\"]', '2025-08-05 09:56:12', NULL, '2025-08-05 09:56:05', '2025-08-05 09:56:12'),
(183, 'App\\Models\\User', 50, 'auth_token', '8c7365e429029f126b5ad717ebe3ebda0a90f573be52dbcb6c3da9408af471d2', '[\"*\"]', '2025-08-07 16:20:29', NULL, '2025-08-05 09:56:09', '2025-08-07 16:20:29'),
(184, 'App\\Models\\Admin', 1, 'admin-token', '2529d58b8217908ceb344c6a702f29999d5bff20e7eddb7bc9eb87133a81bd51', '[\"*\"]', '2025-08-07 21:23:55', NULL, '2025-08-07 21:23:33', '2025-08-07 21:23:55'),
(185, 'App\\Models\\Admin', 1, 'admin-token', '11a83706528bb9e6ab4652b07c4b5ddf084638214e45e611c7b710d373128ff3', '[\"*\"]', '2025-08-08 21:44:11', NULL, '2025-08-08 21:40:43', '2025-08-08 21:44:11'),
(186, 'App\\Models\\Admin', 1, 'admin-token', '92a6d91d0879954211b4d22acacf5fac8acb88a2972a02481b345fdec08bfc49', '[\"*\"]', '2025-08-08 22:31:21', NULL, '2025-08-08 22:30:28', '2025-08-08 22:31:21'),
(187, 'App\\Models\\Admin', 1, 'admin-token', '338a78762bcff9c8d93c9c4005911717bfd768822563b28669bfc1467fa75989', '[\"*\"]', '2025-08-08 23:09:58', NULL, '2025-08-08 22:50:39', '2025-08-08 23:09:58'),
(188, 'App\\Models\\User', 23, 'auth_token', 'a87e6a84b908c15649b3920c3d199c9cba6113c485de4c4cfb594ebfcafc460c', '[\"*\"]', '2025-08-09 12:28:33', NULL, '2025-08-09 12:25:27', '2025-08-09 12:28:33'),
(189, 'App\\Models\\Admin', 1, 'admin-token', '212944501e4ecefddc94266b91a6b82a72492ef6dbba091795f0a12e6470ccd3', '[\"*\"]', '2025-08-09 17:20:16', NULL, '2025-08-09 12:32:51', '2025-08-09 17:20:16'),
(190, 'App\\Models\\Admin', 1, 'admin-token', '5586106a4a946396128a19cb00bda820968c3dd7f5e964415985c542787bc1f1', '[\"*\"]', '2025-08-09 22:47:07', NULL, '2025-08-09 20:59:37', '2025-08-09 22:47:07'),
(191, 'App\\Models\\User', 23, 'auth_token', '86c036b032340035a80c83e3073c5de474448bcf50f3ca2a918fe0a3b2178c20', '[\"*\"]', '2025-08-09 23:47:26', NULL, '2025-08-09 22:48:17', '2025-08-09 23:47:26'),
(192, 'App\\Models\\User', 23, 'auth_token', '6196761ea33c179635ea0952d5369af1d3aba722bb43c647106647bcaee81906', '[\"*\"]', '2025-08-11 05:55:25', NULL, '2025-08-10 15:37:21', '2025-08-11 05:55:25'),
(193, 'App\\Models\\User', 50, 'auth_token', '11980efae9abad456fe025a2448a2e1496495994bf6d9246bd75860be050593d', '[\"*\"]', '2025-08-10 23:44:55', NULL, '2025-08-10 23:44:39', '2025-08-10 23:44:55'),
(194, 'App\\Models\\User', 50, 'auth_token', '48e3bb31260bdb5e03a51a4ef0ccd1db53c1d467d6222149026e5d74eec9f4a6', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:42', '2025-08-10 23:44:42'),
(195, 'App\\Models\\User', 50, 'auth_token', '55e03b7ea3f81c72e6998ca10a45248896cbaf2cb29fc725ef100d1e1546ef9c', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:43', '2025-08-10 23:44:43'),
(196, 'App\\Models\\User', 48, 'auth_token', '2396ce828d1086b74ed425d80370740f6a68103df37029a235814bce82f45882', '[\"*\"]', '2025-08-10 23:44:55', NULL, '2025-08-10 23:44:44', '2025-08-10 23:44:55'),
(197, 'App\\Models\\User', 48, 'auth_token', '2fb2ab527875e2087f0603b02b3ecda40debe20a419552d0e2acb943355a7ad9', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:44', '2025-08-10 23:44:44'),
(198, 'App\\Models\\User', 48, 'auth_token', '85b36239635c8ac0323f8f79888d80bb203cf4691fb93006abf27525dfafca7b', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:45', '2025-08-10 23:44:45'),
(199, 'App\\Models\\User', 48, 'auth_token', 'd6c420e4950fbb0fdc0c75a0023e9221d0ce9693d8707c6027816aca126679b0', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:46', '2025-08-10 23:44:46'),
(200, 'App\\Models\\User', 48, 'auth_token', 'b0fc340b839a741d5a2a6da5f0819298cca50804eaeb2460c6b131b060def0be', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:47', '2025-08-10 23:44:47'),
(201, 'App\\Models\\User', 48, 'auth_token', '0849a3da2f59f0ed363ff7247e578fac2567935500d4aa123317c016a1c20a70', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:47', '2025-08-10 23:44:47'),
(202, 'App\\Models\\User', 48, 'auth_token', 'abd1e99959e8bfbe76943069653a19da5d0fc3290a82d541cc5923ba04e16d00', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:50', '2025-08-10 23:44:50'),
(203, 'App\\Models\\User', 48, 'auth_token', 'b8173a48320684ea0de7362faeb080db4a458daf7d33859c760618d485bcaeaa', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:51', '2025-08-10 23:44:51'),
(204, 'App\\Models\\User', 48, 'auth_token', '342c04b811ab44b0769f825598b96b822667070ff647830f2901a937bcf63482', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:51', '2025-08-10 23:44:51'),
(205, 'App\\Models\\User', 48, 'auth_token', '7dc7c61d368471f36a848b866d583c206e8daa6a241071d8d06448305881a09a', '[\"*\"]', NULL, NULL, '2025-08-10 23:44:53', '2025-08-10 23:44:53'),
(206, 'App\\Models\\User', 48, 'auth_token', '27afe8b48986b54946ea0745792cea93532893847948dc449bce7629e402dde9', '[\"*\"]', '2025-08-10 23:45:29', NULL, '2025-08-10 23:44:53', '2025-08-10 23:45:29'),
(207, 'App\\Models\\User', 50, 'auth_token', 'f59d412284d177ff63427d19c4552e2b6c69f6075aa280b21e4a17ca53fee2ee', '[\"*\"]', '2025-08-12 01:39:25', NULL, '2025-08-10 23:45:50', '2025-08-12 01:39:25'),
(209, 'App\\Models\\User', 23, 'auth_token', '189f8ffa9e422a8d57b6f3fd68e65dfa31985936dfc6c73955fd6572959661ce', '[\"*\"]', '2025-08-12 01:43:17', NULL, '2025-08-12 01:41:00', '2025-08-12 01:43:17'),
(210, 'App\\Models\\User', 50, 'auth_token', '1785cd1a8f291fd072ec6097a1ca6af09b141b63fae663aa88a6c547de8d5f7d', '[\"*\"]', '2025-08-12 23:52:51', NULL, '2025-08-12 01:48:48', '2025-08-12 23:52:51'),
(211, 'App\\Models\\User', 23, 'auth_token', 'a2153a2669342dcbf1a58d6924f985bd227d9e46f172ea690034030f3e30e35e', '[\"*\"]', '2025-08-12 23:56:03', NULL, '2025-08-12 23:53:40', '2025-08-12 23:56:03'),
(213, 'App\\Models\\User', 23, 'auth_token', '31fe480ca5d1f27a1c05b18c877f2d8de95288dc29efde34e76e50aae6eed63a', '[\"*\"]', '2025-08-13 00:10:34', NULL, '2025-08-13 00:09:28', '2025-08-13 00:10:34'),
(216, 'App\\Models\\User', 23, 'auth_token', '5d1f38eda4e85b169aafd9a569f30664d599510e783c9987962689f597b87022', '[\"*\"]', '2025-08-13 00:39:43', NULL, '2025-08-13 00:39:13', '2025-08-13 00:39:43'),
(217, 'App\\Models\\Admin', 1, 'admin-token', '6da70d067c3451f26cf1000f856631eac54306083c1a8648e87065ee5458792e', '[\"*\"]', '2025-08-13 02:24:53', NULL, '2025-08-13 02:22:46', '2025-08-13 02:24:53'),
(218, 'App\\Models\\User', 23, 'auth_token', '6f58727b436474d3a4c76fb9558f12fbae2c71c869499a7986cbccbfc3281b70', '[\"*\"]', '2025-08-13 08:04:49', NULL, '2025-08-13 02:24:41', '2025-08-13 08:04:49'),
(219, 'App\\Models\\Admin', 1, 'admin-token', 'f1d3aaff1cb5a81bee38f4e682d4567b9e3484725903e40678ada4f825303edf', '[\"*\"]', '2025-08-13 02:26:39', NULL, '2025-08-13 02:26:15', '2025-08-13 02:26:39'),
(220, 'App\\Models\\Admin', 1, 'admin-token', 'b2b1c9a171a97ee00e35335519fe4c09fec00f74afcd963e95eb43ac798256ff', '[\"*\"]', '2025-08-14 22:47:02', NULL, '2025-08-13 02:29:32', '2025-08-14 22:47:02'),
(221, 'App\\Models\\User', 23, 'auth_token', '7374fab27cffd7ef41d91c5a03266589e9243fb7ca9ef90aa1391a66746acdba', '[\"*\"]', '2025-08-13 16:12:02', NULL, '2025-08-13 16:11:56', '2025-08-13 16:12:02'),
(222, 'App\\Models\\User', 23, 'auth_token', '26b5de60798f6dc553e3dd0d458439fe5ee9124d83715550c338e75055099f79', '[\"*\"]', NULL, NULL, '2025-08-13 16:11:57', '2025-08-13 16:11:57'),
(223, 'App\\Models\\User', 23, 'auth_token', 'f72919fdeb3582cafa4367f865507289e5dba0f83f35cf3939680cc5d9da659a', '[\"*\"]', '2025-08-13 16:26:58', NULL, '2025-08-13 16:12:01', '2025-08-13 16:26:58'),
(224, 'App\\Models\\User', 23, 'auth_token', 'b055682bb2d406cfda30f4496ed260bf504fd0ab7eabd311be5d4fc2c312aa58', '[\"*\"]', '2025-08-13 18:25:27', NULL, '2025-08-13 16:31:25', '2025-08-13 18:25:27'),
(225, 'App\\Models\\User', 23, 'auth_token', 'f5711224902d17b91fff793cd8605768311bffa599821bd473af3683966babeb', '[\"*\"]', '2025-08-13 16:44:56', NULL, '2025-08-13 16:33:43', '2025-08-13 16:44:56'),
(226, 'App\\Models\\User', 51, 'auth_token', 'e46bad392344449e206888e4690e09583619bc194c08c62fdc7b95aed0147031', '[\"*\"]', NULL, NULL, '2025-08-14 22:47:53', '2025-08-14 22:47:53'),
(227, 'App\\Models\\User', 51, 'auth_token', '074bdbe44ed0a20ca137829bc7ac998367d43b8c2ab20fac355008925f83c25f', '[\"*\"]', '2025-08-14 22:49:32', NULL, '2025-08-14 22:47:55', '2025-08-14 22:49:32'),
(228, 'App\\Models\\User', 51, 'auth_token', '8721d86e3303630d8178ac6b8f400db807ec7559b1cb77b713ed6e0b0af1099d', '[\"*\"]', '2025-08-14 22:49:44', NULL, '2025-08-14 22:49:40', '2025-08-14 22:49:44'),
(229, 'App\\Models\\User', 52, 'auth_token', 'b9a6659c6cc8897c3f9350519d530ff48fbc97dcf486e51a22687a3e9555c7d3', '[\"*\"]', NULL, NULL, '2025-08-14 23:17:34', '2025-08-14 23:17:34'),
(230, 'App\\Models\\User', 52, 'auth_token', '18dcaa914cb514ec291470b8d72b5f9871ddb6e40ecc41dde40945475242ab20', '[\"*\"]', '2025-08-14 23:20:34', NULL, '2025-08-14 23:17:36', '2025-08-14 23:20:34'),
(231, 'App\\Models\\User', 52, 'auth_token', '59366928b67e03b84b6dd296bd45629c9f01888a1b73b85074e470510d7638a2', '[\"*\"]', '2025-08-15 03:32:14', NULL, '2025-08-14 23:20:41', '2025-08-15 03:32:14'),
(232, 'App\\Models\\User', 23, 'auth_token', '4c406619557d4b19cf162c33a25e631b3e4820a71491d188c06f61704c5a0bed', '[\"*\"]', '2025-08-15 16:22:35', NULL, '2025-08-15 11:06:35', '2025-08-15 16:22:35'),
(233, 'App\\Models\\User', 50, 'auth_token', 'df1886c6f2355ee9f538058cc8840bb1c61d8d06b40b47fa567c55d4e2138fd9', '[\"*\"]', '2025-08-15 11:27:18', NULL, '2025-08-15 11:06:39', '2025-08-15 11:27:18'),
(234, 'App\\Models\\Admin', 1, 'admin-token', '5e4cf0bc72a0f1d8e99028a0133bb6e2a3449efd6a6508b2cec2c72b8140af78', '[\"*\"]', '2025-08-15 16:03:34', NULL, '2025-08-15 11:27:39', '2025-08-15 16:03:34'),
(235, 'App\\Models\\User', 23, 'auth_token', '77ae5225e0f0748331ba5d5c935db001432f2b1fa866c2653193659e5a1de038', '[\"*\"]', '2025-08-16 22:00:47', NULL, '2025-08-16 20:26:08', '2025-08-16 22:00:47'),
(236, 'App\\Models\\User', 53, 'auth_token', '24bf7a9797e180e2512e44b0def0c0b3a1f0f20e96b3dd098b7d48ab0e54f8af', '[\"*\"]', NULL, NULL, '2025-08-16 21:57:02', '2025-08-16 21:57:02'),
(237, 'App\\Models\\User', 53, 'auth_token', 'eadd5491605217881ac6863aa45a5b1ff0b05b6e766eb2345888212cd959db12', '[\"*\"]', '2025-08-16 21:57:59', NULL, '2025-08-16 21:57:04', '2025-08-16 21:57:59'),
(238, 'App\\Models\\User', 53, 'auth_token', '2c20ac8962a1e276bdd575141195e118c0e5775a4122211c8d33af717fb09bdc', '[\"*\"]', '2025-08-16 21:59:54', NULL, '2025-08-16 21:58:08', '2025-08-16 21:59:54'),
(239, 'App\\Models\\Admin', 1, 'admin-token', 'a9acb21e9528f8e681c5175c1b3503afb51c4e9d9b9528d82934549f037acaf3', '[\"*\"]', '2025-08-16 22:00:39', NULL, '2025-08-16 21:59:56', '2025-08-16 22:00:39'),
(240, 'App\\Models\\User', 53, 'auth_token', '982f273a20ce5e97490c63a7b683eaa53edb29ebb3a4863319f691c4d6e2811f', '[\"*\"]', '2025-08-16 22:05:12', NULL, '2025-08-16 22:02:31', '2025-08-16 22:05:12'),
(241, 'App\\Models\\User', 23, 'auth_token', '626aa17d90f954e7f64eb3445fc53925e153a532896e49051379c9ecbde7bcce', '[\"*\"]', '2025-08-16 22:28:29', NULL, '2025-08-16 22:06:41', '2025-08-16 22:28:29'),
(242, 'App\\Models\\User', 23, 'auth_token', 'c1d1142dda6652db899b57351e66179cf54fbae4514208e8aab13ecbb51c9833', '[\"*\"]', '2025-08-19 16:12:32', NULL, '2025-08-16 22:07:54', '2025-08-19 16:12:32'),
(243, 'App\\Models\\User', 23, 'auth_token', '351e6bb0f315865964492c45cf48bd0cdde9f2279ba994d5573b16be3850f62b', '[\"*\"]', '2025-08-17 02:22:26', NULL, '2025-08-16 22:29:55', '2025-08-17 02:22:26'),
(244, 'App\\Models\\Admin', 1, 'admin-token', '7a9e9523f55275204476a123820042c68c71adfa79116e696f5049ed08a920b2', '[\"*\"]', '2025-08-18 22:33:57', NULL, '2025-08-18 18:35:24', '2025-08-18 22:33:57'),
(245, 'App\\Models\\User', 53, 'auth_token', 'e84fe8576692ed7317c9c0799f0bc4762e9a71629475b34db2740cf1b57f22fc', '[\"*\"]', '2025-08-19 12:00:38', NULL, '2025-08-19 11:53:19', '2025-08-19 12:00:38'),
(246, 'App\\Models\\User', 23, 'auth_token', '77481d412e9fd2184b0deaeef5ceec10ffb9e8239b91f666c0f5193a76667065', '[\"*\"]', NULL, NULL, '2025-08-19 13:59:20', '2025-08-19 13:59:20'),
(247, 'App\\Models\\User', 53, 'auth_token', '7950ffa1f5118512140a5861a0bf7b4d64472f46b7b92a9d6ee24a0d1c65cb02', '[\"*\"]', NULL, NULL, '2025-08-19 15:33:08', '2025-08-19 15:33:08'),
(248, 'App\\Models\\User', 23, 'auth_token', '1fcf1a39379e7c4d35f286630601f3c2cea6a0c7d01ac9e721930593db57e08c', '[\"*\"]', '2025-08-19 15:49:08', NULL, '2025-08-19 15:45:58', '2025-08-19 15:49:08'),
(249, 'App\\Models\\User', 53, 'auth_token', '889201df6ef214a4248740c79cc9da1249b0910d9586078fcdbfb1fc7dbff6eb', '[\"*\"]', '2025-08-19 15:59:09', NULL, '2025-08-19 15:50:29', '2025-08-19 15:59:09'),
(250, 'App\\Models\\User', 23, 'auth_token', '5db1e146951c2c9a9aaab88b4f6a89699220084ea3d0f9b9f7b5aaf5f452ea4e', '[\"*\"]', '2025-08-19 16:04:57', NULL, '2025-08-19 16:02:10', '2025-08-19 16:04:57'),
(251, 'App\\Models\\User', 53, 'auth_token', '52ed1250be06916d366f9e77959915b53069d06a4d6aaf187978c3d1d6e9678b', '[\"*\"]', '2025-08-19 16:53:39', NULL, '2025-08-19 16:49:04', '2025-08-19 16:53:39'),
(252, 'App\\Models\\User', 23, 'auth_token', '12606c85a32ebfa6b999e37cb8788459294d4dbda3d1d73a7e77e6966ebeff1b', '[\"*\"]', '2025-08-19 16:57:24', NULL, '2025-08-19 16:54:28', '2025-08-19 16:57:24');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(12,2) NOT NULL,
  `stock` int(11) NOT NULL DEFAULT 0,
  `image` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_reviews`
--

CREATE TABLE `product_reviews` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_vendors`
--

CREATE TABLE `product_vendors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `store_address` varchar(255) NOT NULL,
  `store_phone` varchar(255) NOT NULL,
  `store_email` varchar(255) DEFAULT NULL,
  `store_description` text DEFAULT NULL,
  `logo` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_vendors`
--

INSERT INTO `product_vendors` (`id`, `vendor_id`, `contact_person`, `store_address`, `store_phone`, `store_email`, `store_description`, `logo`, `created_at`, `updated_at`) VALUES
(1, 28, 'ade faro', 'Behind Okporo Technical', '08105182929', 'ewuziemt@gmail.com', 'sfgcghvknl;ml', NULL, '2025-08-02 13:59:25', '2025-08-02 13:59:25');

-- --------------------------------------------------------

--
-- Table structure for table `riders`
--

CREATE TABLE `riders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `vehicle_type` enum('bike','tricycle','car') DEFAULT NULL,
  `license_number` varchar(255) DEFAULT NULL,
  `experience_years` int(11) DEFAULT NULL,
  `status` enum('pending','active','suspended') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `riders`
--

INSERT INTO `riders` (`id`, `user_id`, `vendor_id`, `vehicle_type`, `license_number`, `experience_years`, `status`, `created_at`, `updated_at`) VALUES
(1, 31, 12, 'bike', 'A1234567', 3, 'pending', '2025-08-01 08:05:45', '2025-08-01 08:05:45');

-- --------------------------------------------------------

--
-- Table structure for table `rides`
--

CREATE TABLE `rides` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `rider_id` bigint(20) UNSIGNED NOT NULL,
  `status` enum('booked','on_trip','completed','cancelled') NOT NULL DEFAULT 'booked',
  `fare` decimal(10,2) DEFAULT NULL,
  `pickup_lat` decimal(10,6) NOT NULL,
  `pickup_lng` decimal(10,6) NOT NULL,
  `dropoff_lat` decimal(10,6) NOT NULL,
  `dropoff_lng` decimal(10,6) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ride_ratings`
--

CREATE TABLE `ride_ratings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ride_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `comment` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ride_settings`
--

CREATE TABLE `ride_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `base_fare` decimal(10,2) NOT NULL DEFAULT 200.00,
  `rate_per_km` decimal(10,2) NOT NULL DEFAULT 80.00,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `service_apartments`
--

CREATE TABLE `service_apartments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL,
  `organization_name` varchar(255) DEFAULT NULL,
  `organization_address` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `years_of_experience` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_apartments`
--

INSERT INTO `service_apartments` (`id`, `vendor_id`, `full_name`, `phone_number`, `organization_name`, `organization_address`, `website`, `years_of_experience`, `created_at`, `updated_at`) VALUES
(1, 19, 'Jane Doe', '08011112222', 'Palm View Homes', '24 Allen Avenue, Ikeja', 'https://palmviewhomes.ng', '3', '2025-08-01 23:35:12', '2025-08-01 23:35:12'),
(2, 31, 'Est house', '07080038774', 'esthousing', 'Choba', NULL, '2', '2025-08-04 07:02:04', '2025-08-04 07:02:04');

-- --------------------------------------------------------

--
-- Table structure for table `service_orders`
--

CREATE TABLE `service_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `service_vendor_id` bigint(20) UNSIGNED NOT NULL,
  `service_pricing_id` bigint(20) UNSIGNED DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pending_vendor_response','awaiting_payment','paid','completed','declined','vendor_busy') DEFAULT 'pending_vendor_response',
  `notes` text DEFAULT NULL,
  `deadline` date DEFAULT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_orders`
--

INSERT INTO `service_orders` (`id`, `user_id`, `service_vendor_id`, `service_pricing_id`, `amount`, `status`, `notes`, `deadline`, `paid_at`, `completed_at`, `created_at`, `updated_at`) VALUES
(4, 23, 4, NULL, 500.00, 'awaiting_payment', 'Deep cleaning before guests arrive', '2025-08-25', NULL, NULL, '2025-08-19 15:49:08', '2025-08-19 15:59:09'),
(5, 23, 4, NULL, 200.00, 'pending_vendor_response', 'Deep cleaning before guests arrive', '2025-08-25', NULL, NULL, '2025-08-19 16:57:24', '2025-08-19 16:57:24');

-- --------------------------------------------------------

--
-- Table structure for table `service_pricings`
--

CREATE TABLE `service_pricings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `service_vendor_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` decimal(12,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `service_pricings`
--

INSERT INTO `service_pricings` (`id`, `service_vendor_id`, `title`, `price`, `created_at`, `updated_at`) VALUES
(2, 4, '1-Bedroom Cleaning', 300.00, '2025-08-19 12:00:38', '2025-08-19 12:00:38'),
(3, 4, '1-Bedroom Cleaning', 200.00, '2025-08-19 16:53:40', '2025-08-19 16:53:40');

-- --------------------------------------------------------

--
-- Table structure for table `service_vendors`
--

CREATE TABLE `service_vendors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `vendor_id` bigint(20) UNSIGNED NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `location` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `rating` decimal(2,1) DEFAULT 0.0,
  `rating_count` int(11) DEFAULT 0,
  `total_reviews` int(11) DEFAULT 0,
  `is_featured` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_vendors`
--

INSERT INTO `service_vendors` (`id`, `vendor_id`, `service_name`, `description`, `location`, `phone`, `rating`, `rating_count`, `total_reviews`, `is_featured`, `created_at`, `updated_at`) VALUES
(3, 33, 'Writer', 'Writer', 'Choba', '08105182450', 0.0, 0, 0, 0, '2025-08-14 23:20:34', '2025-08-14 23:20:34'),
(4, 34, 'Plumbing', 'Plumbing', 'choba', '08105182900', 0.0, 0, 0, 0, '2025-08-16 21:57:59', '2025-08-16 21:57:59');

-- --------------------------------------------------------

--
-- Table structure for table `service_vendor_ratings`
--

CREATE TABLE `service_vendor_ratings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `service_vendor_id` bigint(20) UNSIGNED NOT NULL,
  `rating` tinyint(4) NOT NULL CHECK (`rating` between 1 and 5),
  `review` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('8fJ9gfVRXtbX66XAiXIJMe4RElruk56YMGbAdcgx', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicnN6eW1vbGFMUnV0blVLSE5SaG1pTEVjYmNPazRWRGtmQzJSNlJJMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1754330201),
('biQtGEaDXbTUCMCsFnDqzlYmVWufrRIRJorg25PA', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoicFR4OVprdEkzZmc4Y0pNVkZHUHhpVnhhdTNzYTlFNUtETTdXY2JZaCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1755562715),
('e14D6LxlXLh4zR0C0TtH5rU8INKJMWWuWYBVuO8e', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibVQybTBUWVVSMW5TeTNmVnU2NW9rTFdIcmdSaFBoalpQZjVXd0hlbiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1754294851),
('Fc62PQaOCO0qEVqCeVhN0s7dpvkKmi9p6smzLHR1', NULL, '127.0.0.1', 'WhatsApp/2.2531.4 W', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoick5RVnd1SFlsWWo0YkxOZWlpeVprTjVydERKREJBTGtNRmlCcTN0biI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly8yNzAyYmNhYzI2Mjgubmdyb2stZnJlZS5hcHAiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1755388522),
('hDG7GXemYz2FGo870PktgeBy8cGkBdKPfNNCJj5w', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVmhZdWhhcHFaMEdlb2F4UDhGMFBOM2pJbktmYXZ3N0VPbGNxTkpweiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1754332175),
('ju1h2BdNRNcvGiplZTy8n7HCb2Vwn0cQ6nltoXiv', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYlg5RVNLTndUV3pBdk1WWmRIUENXczY0MUJOVlVPempKSU43azVzMiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1754006817),
('lr0Zxe5R2t8g3lk0GcCyymKDprURSxKezER0lwZq', NULL, '127.0.0.1', 'WhatsApp/2.2531.4 W', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiNmczc3FsQWk4aTRLeDNxbmUyRjc1VkFRVm1JOGtoVlkwbnJFUVUyYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9hODQwOWI1NGJlYjMubmdyb2stZnJlZS5hcHAiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1755261005),
('Mwezh09NCAamO2uOKQYyPXpYYob4VdR6D2qYyoZI', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoibE1mSVBwY1RvdnlRRlVPekw3Z2pIV3JjZlZWSnBjOEJNeFRVNmFiQSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1754745892),
('qYzKSC2S5zlYNTGVNHpVYa08xwOIb6DIXvCy1qVO', NULL, '127.0.0.1', 'WhatsApp/2.2531.4 W', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiTjNtQ0ttUEZOazQya2txOGxqMTJia2NoWGN6aGQ3cTR3WUFuU0ZzTCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzQ6Imh0dHA6Ly9hODQwOWI1NGJlYjMubmdyb2stZnJlZS5hcHAiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1755297577),
('Ssj0TJfYmdeaSXi03IzkqCcvHrIoJUnJTy4UGAZt', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUldCdkxZVGE5WGdQSDVteDBjcEFkMzNSdlh2QjBocHZhYXlvc3NJdiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1753309311),
('sZN2BpyFYOcNF0vIE5RNuirZLRkdl0Q2uc12IGuV', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUnB3NTFwUHFUUE0zak9tV2Z4TmxUV0pqVUpzSDhMSTREUm10OUY2VCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1754216534),
('TMqYcglsa81ofMfBfp2WonOPiUxgCgrFmZORTDXK', NULL, '127.0.0.1', 'PostmanRuntime/7.44.1', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiUUhaYnVjQ1RyVEo5SFRYTnlEcG41SmJWUDFIT2gzem8xa1RuM0V6ZCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1751756586),
('u8IvNUwLuny0LCkHKObJVFrtprbYf7MzrmOCVFvm', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiYU9iRGp3VmFSZUh1V0pxdHJ1MEtWbWNaTGJJQkFkY1VZbjBxajVIUCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1755625580),
('utHv9BK1l4AIOsVsmivTZQS1yONERCGF8Ymancdy', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiQUtwOFBEalVRV3ZkNGNSNGJIeVVwZ0wyTENwUnQ1TmF2Wm80dlM0UiI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1754157809),
('XHrpdflTehaW1l4L4YZUY8xPfwMXS6H5G9yNLM4w', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWDFjcmhMU2dpN2xxbGVMWjFxNU1hVk9IdmFlVFB1dE53eUxoM1FRViI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=', 1754150708);

-- --------------------------------------------------------

--
-- Table structure for table `subscriptions`
--

CREATE TABLE `subscriptions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `user_type` enum('user','vendor','admin') NOT NULL DEFAULT 'user',
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `phone_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `phone`, `email`, `profile_picture`, `user_type`, `status`, `phone_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(20, 'John Doe', '08012345678', 'johndoe@example.com', NULL, 'vendor', 1, NULL, '$2y$12$IjjH3A9R0rvnSCFP8iFOI.M6u0cTv/3rX13XD8An0kI7wwuZssk7a', NULL, '2025-07-06 15:46:12', '2025-07-06 15:46:12'),
(21, 'Tech god', '08012345679', 'tech@example.com', NULL, 'vendor', 1, NULL, '$2y$12$jI6IOXD.QP7Mqmv9Ppr0iuL7LGsSDSjpX0bRAr1wFNgJ7fh5.qJ/.', NULL, '2025-07-06 16:42:41', '2025-07-06 16:42:41'),
(23, 'kelvin ade', '08105182932', 'tgomori@gmail.com', 'storage/profile_pictures/R3hg0YdlptUoH4HANVBRtsw5mdhjEn5FRtMokOx3.jpg', 'user', 1, NULL, '$2y$12$VEOTxKmmIP6Ec0SI9Z3yh.w7V3Hu/.p4cNsDP1pXeUArBQJbEHHAy', NULL, '2025-07-06 17:55:18', '2025-08-12 01:43:10'),
(31, 'Test Rider', '08099990000', 'testrider@example.com', NULL, 'vendor', 1, NULL, '$2y$12$NFbB6vxeHq.Ib1QE4PwV6ualfsiKdRZGbOdk6ZhHqnePtb1z0EYwy', NULL, '2025-08-01 08:04:07', '2025-08-01 08:04:07'),
(32, 'Vendor Test', '08099994433', 'vendor@example.com', NULL, 'vendor', 1, NULL, '$2y$12$gZ.VSJrx1Sta35QYTp6WguZ6lr6BkAHbjrowbZjdxMusaeQIHFNY2', NULL, '2025-08-01 08:13:26', '2025-08-01 08:13:26'),
(38, 'Jane Doe', '08011112222', 'jane@palmview.ng', NULL, 'vendor', 1, NULL, '$2y$12$x.KZqBo6/pcVwUpBEDV4yOIfxhVke9jbE0EYI4LUKsBzyZAJAkW.q', NULL, '2025-08-01 23:34:05', '2025-08-01 23:34:05'),
(39, 'Mama B', '08011112223', 'Mamab@gmail.com', NULL, 'vendor', 1, NULL, '$2y$12$00ad3V/dwkPaUYoGqRy7veAPYWvddsb5Jy9poXKnO5H0U27PIlk3C', NULL, '2025-08-01 23:41:28', '2025-08-01 23:41:28'),
(47, 'Ade Faro', '08105182929', 'info@adminsrd.com', 'storage/profile_pictures/xvjEw1Z1ifrQS2dprtE3IKTiD4wsvXDq6w6fHC6O.png', 'vendor', 1, NULL, '$2y$12$edIke1DrYK6aTl6LTXR/FuExPRhMIVLPn.xfDj8c89N6foqjybs4m', NULL, '2025-08-02 13:58:54', '2025-08-03 15:06:30'),
(48, 'ewuziem trustGod', '08105182903', 'ewuziemt@gmail.com', 'storage/profile_pictures/Jwm4x603WtoEtD6FjhwB5tSl1Zfsfpkc5GkPiok1.jpg', 'vendor', 1, '2025-08-02 22:24:14', '$2y$12$OgjLtfd2PSLQGtSshiYPfO0DdNG5rQKxPwK7YSfjtWEKoAmC2WhKm', NULL, '2025-08-02 22:22:51', '2025-08-02 22:25:42'),
(50, 'Est Housing', '08105182901', 'universetg98@gmail.com', NULL, 'vendor', 1, '2025-08-07 16:12:17', '$2y$12$4Gorp8io0O5aSBaGf7VELuciC15b8r2Zn.MnGW3buop2nwjgFLAxe', NULL, '2025-08-04 07:01:15', '2025-08-07 16:12:17'),
(52, 'New vend', '08105182450', 'tgomori98@gmail.com', NULL, 'vendor', 1, NULL, '$2y$12$7RRQVMi8ZmVMqBpdcUhm/eDv6dAsA6U5uVNDeT5piTOYzH9EUFcP6', NULL, '2025-08-14 23:17:34', '2025-08-14 23:17:34'),
(53, 'Mr Fixer Ewuziem', '08105182900', 'fixer@gmail.com', NULL, 'vendor', 1, '2025-08-16 21:59:35', '$2y$12$UDztQL3b8H0z684AzH/XDuqnzSfq8WQklcTHO2cpH4yXz9L7AjlYG', NULL, '2025-08-16 21:57:02', '2025-08-16 21:59:35');

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `vendor_type` enum('individual','business') NOT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `category` enum('product_vendor','mechanic','service_vendor','service_apartment','food_vendor','rider') NOT NULL COMMENT 'Specifies the business category of the vendor',
  `is_setup_complete` tinyint(1) NOT NULL DEFAULT 0,
  `is_verified` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`id`, `user_id`, `vendor_type`, `business_name`, `category`, `is_setup_complete`, `is_verified`, `created_at`, `updated_at`) VALUES
(5, 20, 'individual', 'FixIt Autos', 'mechanic', 0, 0, '2025-07-06 15:47:23', '2025-07-06 15:47:23'),
(6, 21, 'individual', 'Nexus', 'mechanic', 0, 0, '2025-07-06 16:43:47', '2025-07-06 16:43:47'),
(12, 31, 'individual', 'RiderX', 'rider', 0, 0, '2025-08-01 08:05:04', '2025-08-01 08:05:04'),
(13, 32, 'business', 'SuperStore NG', 'product_vendor', 0, 0, '2025-08-01 08:14:49', '2025-08-01 08:14:49'),
(19, 38, 'business', 'Palm View Homes', 'service_apartment', 1, 0, '2025-08-01 23:34:40', '2025-08-01 23:35:12'),
(20, 39, 'business', 'Mama Blessing', 'food_vendor', 1, 0, '2025-08-01 23:44:46', '2025-08-01 23:58:02'),
(28, 47, 'individual', 'tg stores', 'product_vendor', 1, 0, '2025-08-02 13:59:06', '2025-08-03 09:24:29'),
(29, 48, 'individual', 'mectg', 'mechanic', 1, 1, '2025-08-02 22:23:09', '2025-08-03 08:29:52'),
(31, 50, 'individual', 'esthousing', 'service_apartment', 1, 1, '2025-08-04 07:01:29', '2025-08-04 07:08:30'),
(33, 52, 'individual', 'writer', 'service_vendor', 1, 0, '2025-08-14 23:19:58', '2025-08-14 23:20:34'),
(34, 53, 'individual', 'Plumfix', 'service_vendor', 1, 1, '2025-08-16 21:57:17', '2025-08-16 22:00:24');

-- --------------------------------------------------------

--
-- Table structure for table `verifications`
--

CREATE TABLE `verifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('NIN','CAC') NOT NULL,
  `value` varchar(255) DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `document_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `verifications`
--

INSERT INTO `verifications` (`id`, `user_id`, `type`, `value`, `status`, `verified_at`, `created_at`, `updated_at`, `document_url`) VALUES
(2, 48, 'NIN', NULL, 'approved', '2025-08-03 08:29:52', '2025-08-02 22:24:32', '2025-08-03 08:29:52', 'compliance_docs/VlU9fWzxo2pRTkps2sR9w4ten6XdYwSFLOXveHWD.png'),
(4, 50, 'NIN', NULL, 'approved', '2025-08-04 07:08:30', '2025-08-04 07:03:50', '2025-08-04 07:08:30', 'compliance_docs/sJ3Q4DaaY7h5H7bMK1Vh7jGmLBRh3cCehtHVxAis.png'),
(5, 53, 'NIN', NULL, 'approved', '2025-08-16 22:00:24', '2025-08-16 21:59:52', '2025-08-16 22:00:24', 'compliance_docs/YYzLKqnA9L9AqrlHgq960Y4E3cvN06e3liMdbYSm.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `wallets`
--

CREATE TABLE `wallets` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `currency` varchar(255) NOT NULL DEFAULT 'NGN',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wallets`
--

INSERT INTO `wallets` (`id`, `user_id`, `balance`, `currency`, `created_at`, `updated_at`) VALUES
(1, 31, 2880.00, 'NGN', '2025-08-11 01:13:17', '2025-08-11 05:55:25'),
(2, 23, 0.00, 'NGN', '2025-08-13 05:37:31', '2025-08-13 05:37:31');

-- --------------------------------------------------------

--
-- Table structure for table `wallet_transactions`
--

CREATE TABLE `wallet_transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `wallet_id` bigint(20) UNSIGNED NOT NULL,
  `performed_by` enum('user','vendor') NOT NULL DEFAULT 'user',
  `description` text DEFAULT NULL,
  `related_type` varchar(255) DEFAULT NULL,
  `related_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` enum('credit','debit') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `status` enum('pending','success','failed') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `wallet_transactions`
--

INSERT INTO `wallet_transactions` (`id`, `wallet_id`, `performed_by`, `description`, `related_type`, `related_id`, `type`, `amount`, `ref`, `status`, `created_at`, `updated_at`) VALUES
(4, 1, 'user', NULL, NULL, NULL, 'credit', 720.00, 'booking_1', 'success', '2025-08-11 05:55:25', '2025-08-11 05:55:25'),
(5, 2, 'user', NULL, NULL, NULL, 'debit', 200.00, 'ye5h3qm1rx', 'success', '2025-08-13 05:37:31', '2025-08-13 05:37:31'),
(6, 2, 'user', NULL, NULL, NULL, 'debit', 200.00, 'flw_test_ref_SO3', 'success', '2025-08-17 02:14:17', '2025-08-17 02:14:17'),
(7, 2, 'user', NULL, NULL, NULL, 'debit', 200.00, 'flw_test_ref_SO3', 'success', '2025-08-17 02:28:09', '2025-08-17 02:28:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `admin_transactions`
--
ALTER TABLE `admin_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_transactions_admin_wallet_id_foreign` (`admin_wallet_id`);

--
-- Indexes for table `admin_wallets`
--
ALTER TABLE `admin_wallets`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `apartments`
--
ALTER TABLE `apartments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `apartments_vendor_id_foreign` (`vendor_id`);

--
-- Indexes for table `apartment_bookings`
--
ALTER TABLE `apartment_bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `apartment_bookings_user_id_foreign` (`user_id`),
  ADD KEY `apartment_bookings_apartment_id_foreign` (`apartment_id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bookings_user_id_foreign` (`user_id`),
  ADD KEY `bookings_listing_id_foreign` (`listing_id`),
  ADD KEY `bookings_vendor_id_foreign` (`vendor_id`);

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `carts_user_id_item_type_item_id_unique` (`user_id`,`item_type`,`item_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `food_menus`
--
ALTER TABLE `food_menus`
  ADD PRIMARY KEY (`id`),
  ADD KEY `food_menus_vendor_id_foreign` (`vendor_id`);

--
-- Indexes for table `food_orders`
--
ALTER TABLE `food_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `food_orders_user_id_foreign` (`user_id`),
  ADD KEY `food_orders_vendor_id_foreign` (`vendor_id`);

--
-- Indexes for table `food_order_items`
--
ALTER TABLE `food_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `food_order_items_food_order_id_foreign` (`food_order_id`),
  ADD KEY `food_order_items_food_menu_id_foreign` (`food_menu_id`);

--
-- Indexes for table `food_vendors`
--
ALTER TABLE `food_vendors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `food_vendors_vendor_id_foreign` (`vendor_id`);

--
-- Indexes for table `gps_logs`
--
ALTER TABLE `gps_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `gps_logs_ride_id_foreign` (`ride_id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `listings`
--
ALTER TABLE `listings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `maintenance_requests`
--
ALTER TABLE `maintenance_requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `maintenance_requests_user_id_foreign` (`user_id`);

--
-- Indexes for table `mechanics`
--
ALTER TABLE `mechanics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mechanics_user_id_foreign` (`user_id`),
  ADD KEY `mechanics_vendor_id_foreign` (`vendor_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_items_order_id_foreign` (`order_id`),
  ADD KEY `order_items_product_id_foreign` (`product_id`);

--
-- Indexes for table `otps`
--
ALTER TABLE `otps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `otps_user_id_foreign` (`user_id`);

--
-- Indexes for table `p2p_transfers`
--
ALTER TABLE `p2p_transfers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `p2p_transfers_sender_id_foreign` (`sender_id`),
  ADD KEY `p2p_transfers_receiver_id_foreign` (`receiver_id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_vendor_id_foreign` (`vendor_id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_reviews`
--
ALTER TABLE `product_reviews`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_reviews_user_id_foreign` (`user_id`),
  ADD KEY `product_reviews_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_vendors`
--
ALTER TABLE `product_vendors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_vendors_vendor_id_foreign` (`vendor_id`);

--
-- Indexes for table `riders`
--
ALTER TABLE `riders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `riders_user_id_foreign` (`user_id`),
  ADD KEY `riders_vendor_id_foreign` (`vendor_id`);

--
-- Indexes for table `rides`
--
ALTER TABLE `rides`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rides_user_id_foreign` (`user_id`),
  ADD KEY `rides_rider_id_foreign` (`rider_id`);

--
-- Indexes for table `ride_ratings`
--
ALTER TABLE `ride_ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ride_ratings_ride_id_foreign` (`ride_id`),
  ADD KEY `ride_ratings_user_id_foreign` (`user_id`);

--
-- Indexes for table `ride_settings`
--
ALTER TABLE `ride_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_apartments`
--
ALTER TABLE `service_apartments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_apartments_vendor_id_foreign` (`vendor_id`);

--
-- Indexes for table `service_orders`
--
ALTER TABLE `service_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `service_vendor_id` (`service_vendor_id`),
  ADD KEY `service_orders_service_pricing_id_foreign` (`service_pricing_id`);

--
-- Indexes for table `service_pricings`
--
ALTER TABLE `service_pricings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_pricings_service_vendor_id_foreign` (`service_vendor_id`);

--
-- Indexes for table `service_vendors`
--
ALTER TABLE `service_vendors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vendor_id` (`vendor_id`);

--
-- Indexes for table `service_vendor_ratings`
--
ALTER TABLE `service_vendor_ratings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `service_vendor_id` (`service_vendor_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `subscriptions`
--
ALTER TABLE `subscriptions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subscriptions_email_unique` (`email`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_phone_unique` (`phone`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vendors_user_id_foreign` (`user_id`);

--
-- Indexes for table `verifications`
--
ALTER TABLE `verifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `verifications_user_id_foreign` (`user_id`);

--
-- Indexes for table `wallets`
--
ALTER TABLE `wallets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wallets_user_id_foreign` (`user_id`);

--
-- Indexes for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `wallet_transactions_wallet_id_foreign` (`wallet_id`),
  ADD KEY `wallet_transactions_related_index` (`related_id`,`related_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_transactions`
--
ALTER TABLE `admin_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `admin_wallets`
--
ALTER TABLE `admin_wallets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `apartments`
--
ALTER TABLE `apartments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `apartment_bookings`
--
ALTER TABLE `apartment_bookings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food_menus`
--
ALTER TABLE `food_menus`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food_orders`
--
ALTER TABLE `food_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food_order_items`
--
ALTER TABLE `food_order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `food_vendors`
--
ALTER TABLE `food_vendors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `gps_logs`
--
ALTER TABLE `gps_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `listings`
--
ALTER TABLE `listings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `maintenance_requests`
--
ALTER TABLE `maintenance_requests`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mechanics`
--
ALTER TABLE `mechanics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `otps`
--
ALTER TABLE `otps`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `p2p_transfers`
--
ALTER TABLE `p2p_transfers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=253;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_reviews`
--
ALTER TABLE `product_reviews`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_vendors`
--
ALTER TABLE `product_vendors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `riders`
--
ALTER TABLE `riders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `rides`
--
ALTER TABLE `rides`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ride_ratings`
--
ALTER TABLE `ride_ratings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ride_settings`
--
ALTER TABLE `ride_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `service_apartments`
--
ALTER TABLE `service_apartments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `service_orders`
--
ALTER TABLE `service_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `service_pricings`
--
ALTER TABLE `service_pricings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `service_vendors`
--
ALTER TABLE `service_vendors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `service_vendor_ratings`
--
ALTER TABLE `service_vendor_ratings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `subscriptions`
--
ALTER TABLE `subscriptions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `verifications`
--
ALTER TABLE `verifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `wallets`
--
ALTER TABLE `wallets`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_transactions`
--
ALTER TABLE `admin_transactions`
  ADD CONSTRAINT `admin_transactions_admin_wallet_id_foreign` FOREIGN KEY (`admin_wallet_id`) REFERENCES `admin_wallets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `apartments`
--
ALTER TABLE `apartments`
  ADD CONSTRAINT `apartments_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `apartment_bookings`
--
ALTER TABLE `apartment_bookings`
  ADD CONSTRAINT `apartment_bookings_apartment_id_foreign` FOREIGN KEY (`apartment_id`) REFERENCES `apartments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `apartment_bookings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `bookings`
--
ALTER TABLE `bookings`
  ADD CONSTRAINT `bookings_listing_id_foreign` FOREIGN KEY (`listing_id`) REFERENCES `listings` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookings_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `food_menus`
--
ALTER TABLE `food_menus`
  ADD CONSTRAINT `food_menus_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `food_orders`
--
ALTER TABLE `food_orders`
  ADD CONSTRAINT `food_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `food_orders_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `food_order_items`
--
ALTER TABLE `food_order_items`
  ADD CONSTRAINT `food_order_items_food_menu_id_foreign` FOREIGN KEY (`food_menu_id`) REFERENCES `food_menus` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `food_order_items_food_order_id_foreign` FOREIGN KEY (`food_order_id`) REFERENCES `food_orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `food_vendors`
--
ALTER TABLE `food_vendors`
  ADD CONSTRAINT `food_vendors_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `gps_logs`
--
ALTER TABLE `gps_logs`
  ADD CONSTRAINT `gps_logs_ride_id_foreign` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `maintenance_requests`
--
ALTER TABLE `maintenance_requests`
  ADD CONSTRAINT `maintenance_requests_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `mechanics`
--
ALTER TABLE `mechanics`
  ADD CONSTRAINT `mechanics_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `mechanics_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `otps`
--
ALTER TABLE `otps`
  ADD CONSTRAINT `otps_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `p2p_transfers`
--
ALTER TABLE `p2p_transfers`
  ADD CONSTRAINT `p2p_transfers_receiver_id_foreign` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `p2p_transfers_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `products_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_reviews`
--
ALTER TABLE `product_reviews`
  ADD CONSTRAINT `product_reviews_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `product_reviews_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_vendors`
--
ALTER TABLE `product_vendors`
  ADD CONSTRAINT `product_vendors_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `riders`
--
ALTER TABLE `riders`
  ADD CONSTRAINT `riders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `riders_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `rides`
--
ALTER TABLE `rides`
  ADD CONSTRAINT `rides_rider_id_foreign` FOREIGN KEY (`rider_id`) REFERENCES `riders` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `rides_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `ride_ratings`
--
ALTER TABLE `ride_ratings`
  ADD CONSTRAINT `ride_ratings_ride_id_foreign` FOREIGN KEY (`ride_id`) REFERENCES `rides` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ride_ratings_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `service_apartments`
--
ALTER TABLE `service_apartments`
  ADD CONSTRAINT `service_apartments_vendor_id_foreign` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `service_orders`
--
ALTER TABLE `service_orders`
  ADD CONSTRAINT `service_orders_service_pricing_id_foreign` FOREIGN KEY (`service_pricing_id`) REFERENCES `service_pricings` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `service_orders_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `service_orders_vendor_fk` FOREIGN KEY (`service_vendor_id`) REFERENCES `service_vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `service_pricings`
--
ALTER TABLE `service_pricings`
  ADD CONSTRAINT `service_pricings_service_vendor_id_foreign` FOREIGN KEY (`service_vendor_id`) REFERENCES `service_vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `service_vendors`
--
ALTER TABLE `service_vendors`
  ADD CONSTRAINT `service_vendors_ibfk_1` FOREIGN KEY (`vendor_id`) REFERENCES `vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `service_vendor_ratings`
--
ALTER TABLE `service_vendor_ratings`
  ADD CONSTRAINT `ratings_user_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ratings_vendor_fk` FOREIGN KEY (`service_vendor_id`) REFERENCES `service_vendors` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `vendors`
--
ALTER TABLE `vendors`
  ADD CONSTRAINT `vendors_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `verifications`
--
ALTER TABLE `verifications`
  ADD CONSTRAINT `verifications_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wallets`
--
ALTER TABLE `wallets`
  ADD CONSTRAINT `wallets_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `wallet_transactions`
--
ALTER TABLE `wallet_transactions`
  ADD CONSTRAINT `wallet_transactions_wallet_id_foreign` FOREIGN KEY (`wallet_id`) REFERENCES `wallets` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
